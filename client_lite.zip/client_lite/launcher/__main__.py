#!/user/bin/env python
# -*- coding:utf-8 -*-

"""
 __main__

"""

if __name__ == '__main__':
    from launcher.cli import main
    main()
