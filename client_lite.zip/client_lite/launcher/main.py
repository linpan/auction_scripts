#!/user/bin/env python
# -*- coding:utf-8 -*-
# main.py
# 主程序入口
#  custom function with lower letter by pep8 rules
# 自定义函数命名根据pep8规则， 一律采用小写

# sys packages
import sys
import subprocess
from os import path

import wx

import config


__version__ = '0.0.1.2018'


class LauncherApp(wx.App):
    """
    程序入口
    定义了基本的窗口描述
    """
    # OnInit method is only for classes that derive wx.App

    def OnInit(self):
        """
        OnInit()方法中定义的一个子类的一个实例，
        当程序启动时，OnInit()方法将被wx.App父类调用
        :return: bool
        """
        self.frame = MainFrame(None, title=u'诚轩现场拍卖系统v1.0', size=(700, 230),)
        # 应用程序的顶级窗口
        self.SetTopWindow(self.frame)
        self.frame.Show()

        return True


class MainFrame(wx.Frame):
    """
     定义主框架，继承Frame
    """

    def __init__(self, *args, **kwargs):
        super(MainFrame, self).__init__(*args, **kwargs)

        self.panel = MainPanel(self)
        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(self.panel, 1, wx.EXPAND)
        self.SetSizer(sizer)
        self.Center()


class MainPanel(wx.Panel):
    """
    pannel class
    """

    def __init__(self, parent):
        wx.Panel.__init__(self, parent)

        self.ui_font = None

        section_informations = (
            {
                'label': u'现场管理',
                'buttons': [(u'现场拍卖(L)', 'auction_live'),
                            (u'网络检查(N)', 'network_status'),
                            (u'POST开启(K)', 'on_post'),
                            (u'POST关闭(G)', 'off_post')
                            ]
            },

        )

        self.sizer = wx.BoxSizer(wx.VERTICAL)
        bFirst = True
        for section in section_informations:
            if bFirst:
                bFirst = False
            else:
                self.sizer.AddSpacer(4)
            top_sizer = self._generate_section(section)
            self.sizer.Add(top_sizer, 1, wx.EXPAND)
        bottom_sizer = wx.StaticBoxSizer(
            wx.StaticBox(self, label=u'有关注意事项'), wx.HORIZONTAL)

        self.sizer.Add(bottom_sizer, 1, wx.EXPAND)

        self._hotheys(section_informations)
        self._defaultfont()
        self.SetSizer(self.sizer)

    def _hotheys(self, section_informations):
        """
        define a set of shortcus keys
        # 快捷键设置
        根据按钮的字母，直接启动
        # TODO 根据实际情况是否ctrl+k的快捷方式
        :return:
        """

        top_win = self.GetTopLevelParent()
        letters_keys = []
        for section in section_informations:
            for label in section['buttons']:
                try:
                    btn = self.FindWindowByLabel(label[0])
                    top_win.Bind(wx.EVT_MENU, self.launch, id=btn.GetId())
                    letters_keys.append(
                        (wx.ACCEL_NORMAL, ord(btn.GetLabel()[-2]), btn.GetId()))
                except Exception as e:
                    print (u'app not exits, please check app packages')
        accel_keys = wx.AcceleratorTable(letters_keys)
        top_win.SetAcceleratorTable(accel_keys)

    def _generate_section(self, section_info):
        """
         generate staticboxsizer
        :param section_info: tuple
        :return: sizer : object
        """
        sizer = wx.StaticBoxSizer(
            wx.StaticBox(
                self,
                label=section_info['label']),
            wx.HORIZONTAL)

        for btn_label in section_info['buttons']:
            app_path = path.join(config.root_path(), btn_label[1] + '.exe')

            # TODO 后期根据实际情况考虑是否保留着？
            if config.is_frozen() and not path.exists(app_path):
                continue  # windows 下将程序打包成 exe 的库
            btn = CustomButton(self, label=btn_label[0])
            if btn_label[1]:
                btn.data = btn_label[1]
                self.Bind(wx.EVT_BUTTON, self.launch, btn)
            sizer.Add(btn, 1, wx.EXPAND)
            sizer.AddSpacer(4)

        return sizer

    def _defaultfont(self):
        # under wxWindowList see
        # http://docs.wxwidgets.org/3.0/classwx_window.html
        wxWindowList = self.GetChildren()
        if not self.ui_font:
            # TODO INSTALL YAHEI FONT FOR MAC
            self.ui_font = wx.Font(
                12,
                wx.DEFAULT,
                wx.NORMAL,
                wx.NORMAL,
                False,
                u'微软雅黑')
        for win in wxWindowList:
            win.SetFont(self.ui_font)

    def launch(self, event):
        btn = self.FindWindowById(event.GetId())
        if sys.platform == 'win32' or sys.platform == 'cygwin':
            if config.is_frozen():
                subprocess.Popen(["%s.exe" % btn.data]).pid
            else:
                subprocess.Popen(['pythonw', '../run.py', btn.data]).pid
        else:
            subprocess.Popen(['pythonw', '../run.py', btn.data]).pid


class CustomButton(wx.Button):
    """
     button class
    """

    def __init__(self, *args, **kwargs):
        self._data = None
        super(CustomButton, self).__init__(*args, **kwargs)

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, data):
        self._data = data


def run():
    app = LauncherApp(False)
    app.MainLoop()


if __name__ == '__main__':
    run()
