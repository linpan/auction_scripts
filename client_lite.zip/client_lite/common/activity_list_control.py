import wx
from lib.utils import GetActiveActID
from lib.rest_client import *

class ActivityBasedPanel(wx.Panel):
    def __init__(self, parent):
        wx.Panel.__init__(self, parent)
        self.activities = None
        self.cur_act = None
        self.prev_act = None
        self.is_init = True

    def BuildActivityChoice(self):
        self.activities = get('/activities')['results']
        self.act_choice_id = wx.NewId()
        choice = wx.Choice(self, self.act_choice_id, choices=[a['name'] for a in self.activities])
        self.Bind(wx.EVT_CHOICE, self.HandleActivityChange, choice)
        return choice

    def SelectActiveAct(self):
        choice = self.FindWindowById(self.act_choice_id)
        for i, a in enumerate(self.activities):
            if a['id'] == GetActiveActID():
                choice.Select(i)
                self.cur_act = a

    def HandleActivityChange(self, evt):
        if self.is_init == True:
            self.is_init = False
        index = evt.EventObject.GetSelection()
        self.cur_act = self.activities[index]
        if self.cur_act == self.prev_act:
            return
        else:
            self.RefreshList()
            self.prev_act = self.cur_act
