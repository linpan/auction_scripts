#!/user/bin/env python
# -*- coding:utf-8 -*-
# 命令参数解析
# pythonw ./run.py app

import sys
from os import path
from optparse import OptionParser
import importlib
import config


# def dynamic_import(module):
#     return importlib.import_module(module)


parser = OptionParser()
parser.add_option("-q", "--quit", action="store_false", dest="verbose",
                  default=True, help="python ./run.py app")

(options, args) = parser.parse_args()

root_dir = config.root_path()
if root_dir not in sys.path:
    sys.path.insert(0, root_dir)
print sys.path
if len(args) > 0:
    app = args[0]
else:
    app = 'launcher'

if not path.exists(path.join(root_dir, app)):
    raise 'args(%s) is not found' % app


mod = importlib.import_module("%s.main" % app)
# 启动app的主程序
mod.run()
