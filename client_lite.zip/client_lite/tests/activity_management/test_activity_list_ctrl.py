# encoding: UTF-8

from flexmock import flexmock
from nose.tools import *
import wx

from lib.mixin import MixIn, UnmixIn

from activity_management.activity_list_ctrl import ActivityListCtrlMixin
import activity_management.activity_list_ctrl as alc

class TestActivityListCtrlMixin:
  def setUp(self):
    self.o = flexmock()
    MixIn(self.o.__class__, ActivityListCtrlMixin)

  def tearDown(self):
    UnmixIn(self.o.__class__, ActivityListCtrlMixin)

  def test_PopulateData_with_single_data(self):
    self.o.should_receive('InsertStringItem').with_args(0, 'foobar').and_return(1).once
    self.o.should_receive('SetItemData').with_args(1, 1).once
    self.o.PopulateData({'id' : 1, 'name' : "foobar"})

  def test_PopulateData_with_n_datas(self):
    self.o.should_receive('InsertStringItem').with_args(0, 'foo').and_return(1).once
    self.o.should_receive('InsertStringItem').with_args(0, 'bar').and_return(2).once
    self.o.should_receive('SetItemData').with_args(1, 1).once
    self.o.should_receive('SetItemData').with_args(2, 2).once
    self.o.PopulateData([{'id' : 1, 'name' : "foo"},
                         {'id' : 2, 'name' : 'bar'}])

  def test_PopulateData_with_n_data2(self):
    self.o.should_receive('InsertStringItem').with_args(0, 'foo').and_return(1).once
    self.o.should_receive('InsertStringItem').with_args(0, 'bar').and_return(2).once
    self.o.should_receive('SetItemData').with_args(1, 1).once
    self.o.should_receive('SetItemData').with_args(2, 2).once
    self.o.PopulateData([{'id' : 1, 'name' : "foo"},
                         {},
                         {'id' : 2, 'name' : 'bar'}])

  def test_CreateNewActivity(self):
    dlg = flexmock(ShowModal=lambda: wx.ID_OK,
                   GetValue=lambda: ' foo bar ')
    flexmock(wx.TextEntryDialog).new_instances(dlg)

    resp = flexmock()
    flexmock(alc).should_receive('post')\
        .with_args('/activities', {'name' : 'foo bar'})\
        .and_return(resp).once

    parent = flexmock()
    self.o.should_receive('GetParent').and_return(parent).once
    self.o.should_receive('PopulateData').with_args(resp).once
    self.o.CreateNewActivity()

  def test_CreateNewActivity_with_empty_input(self):
    dlg = flexmock(ShowModal=lambda: wx.ID_OK,
                   GetValue=lambda: '  ')
    flexmock(wx.TextEntryDialog).new_instances(dlg)
    flexmock(wx.MessageBox).new_instances(wx.ID_OK)

    parent = flexmock()
    self.o.should_receive('GetParent').and_return(parent).once
    flexmock(alc).should_receive('post')\
        .with_args(object, object).never
    self.o.should_receive('PopulateData').with_args(object).never
    self.o.CreateNewActivity()

  def test_UpdateActivity(self):
    self.o.should_receive('_EnsureItemSelected').and_return(0).once
    self.o.should_receive('GetItemText').with_args(0).and_return(u'秋季拍卖会').once
    _id = 1
    self.o.should_receive('GetItemData').with_args(0).and_return(_id).once
    self.o.should_receive('GetParent').and_return(flexmock()).once

    new_name = u' 诚轩秋季拍卖会 '
    dlg = flexmock(ShowModal=lambda: wx.ID_OK,
                   GetValue=lambda: new_name)
    flexmock(wx.TextEntryDialog).new_instances(dlg)

    flexmock(alc).should_receive('put').with_args(
      '/activity/%s' % _id, {'name' : new_name.strip().encode('utf-8')}).once
    self.o.should_receive('SetItemText').with_args(0, new_name.strip()).once
    self.o.UpdateActivity()

  def test_DeleteActivity(self):
    self.o.should_receive('_EnsureItemSelected').and_return(0).once
    self.o.should_receive('GetItemText').with_args(0).and_return(u'秋季拍卖会').once
    _id = 1
    self.o.should_receive('GetItemData').with_args(0).and_return(_id).once

    flexmock(wx.MessageBox).new_instances(wx.ID_YES)
    flexmock(alc).should_receive('delete').with_args('/activity/%s' % _id).once
    self.o.should_receive('DeleteItem').with_args(0).once
    self.o.DeleteActivity()

  def test_GetSelectedItem(self):
    start_index = -1
    self.o.should_receive('GetNextItem').with_args(
      start_index, wx.LIST_NEXT_ALL, wx.LIST_STATE_SELECTED).and_return(-1).once
    assert_is_none(self.o.GetSelectedItem(start_index))

    start_index = -1
    self.o.should_receive('GetNextItem').with_args(
      start_index, wx.LIST_NEXT_ALL, wx.LIST_STATE_SELECTED).and_return(0).once
    assert_equal(self.o.GetSelectedItem(start_index), 0)

