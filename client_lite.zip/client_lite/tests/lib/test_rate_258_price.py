# encoding: UTF-8

from lib.rate_258_price import Rate258Price
from nose.tools import *

class TestRate258Price:
  def test_up1(self):
    rate = Rate258Price(2)
    assert_equal(2000, rate.up(10200))
    assert_equal(3000, rate.up(12200))
    assert_equal(3000, rate.up(15200))
    assert_equal(2000, rate.up(18200))
    assert_equal(2000, rate.up(20200))

    assert_equal(1000, rate.up(21200))
    assert_equal(3000, rate.up(22200))
    assert_equal(2000, rate.up(23200))
    assert_equal(1000, rate.up(24200))
    assert_equal(3000, rate.up(25200))
    assert_equal(2000, rate.up(26200))
    assert_equal(1000, rate.up(27200))
    assert_equal(2000, rate.up(28200))
    assert_equal(1000, rate.up(29200))

    rate = Rate258Price(3)
    assert_equal(300, rate.up(10200))
    assert_equal(300, rate.up(10500))
    assert_equal(200, rate.up(10800))
    assert_equal(200, rate.up(11000))

    assert_equal(100, rate.up(11100))
    assert_equal(300, rate.up(11200))
    assert_equal(200, rate.up(11300))
    assert_equal(100, rate.up(11400))
    assert_equal(300, rate.up(11500))
    assert_equal(200, rate.up(11600))
    assert_equal(100, rate.up(11700))
    assert_equal(200, rate.up(11800))
    assert_equal(100, rate.up(11900))

  def test_up2(self):
    rate = Rate258Price(2)
    assert_equal(0, rate.up(0))
    assert_equal(0, rate.up(2))

    assert_equal(2, rate.up(10))
    assert_equal(3, rate.up(12))
    assert_equal(3, rate.up(15))
    assert_equal(2, rate.up(18))
    assert_equal(2, rate.up(20))

    assert_equal(0, rate.up(110))

    rate = Rate258Price(3)
    assert_equal(0, rate.up(0))
    assert_equal(0, rate.up(10))
    assert_equal(0, rate.up(12))

    assert_equal(3, rate.up(112))
    assert_equal(3, rate.up(115))
    assert_equal(2, rate.up(118))

    assert_equal(200, rate.up(1000))

  def test_down1(self):
    rate = Rate258Price(2)
    assert_equal(-2000, rate.down(10200))
    assert_equal(-200, rate.down(8200))
    assert_equal(-200, rate.down(8000))
    assert_equal(-300, rate.down(7800))
    assert_equal(-300, rate.down(7500))
    assert_equal(-200, rate.down(7200))

    assert_equal(-200, rate.down(7000))
    assert_equal(-100, rate.down(6900))
    assert_equal(-300, rate.down(6800))
    assert_equal(-200, rate.down(6700))
    assert_equal(-100, rate.down(6600))
    assert_equal(-300, rate.down(6500))
    assert_equal(-200, rate.down(6400))
    assert_equal(-100, rate.down(6300))
    assert_equal(-200, rate.down(6200))
    assert_equal(-100, rate.down(6100))

    rate = Rate258Price(3)
    assert_equal(-200, rate.down(10200))
    assert_equal(-200, rate.down(10000))
    assert_equal(-20, rate.down(9800))
    assert_equal(-30, rate.down(9780))
    assert_equal(-30, rate.down(9750))
    assert_equal(-20, rate.down(9720))
    assert_equal(-20, rate.down(9700))

    assert_equal(-200, rate.up(1000))

    assert_equal(-20, rate.down(9700))
    assert_equal(-10, rate.down(9690))
    assert_equal(-30, rate.down(9680))
    assert_equal(-20, rate.down(9670))
    assert_equal(-10, rate.down(9660))
    assert_equal(-30, rate.down(9650))
    assert_equal(-20, rate.down(9640))
    assert_equal(-10, rate.down(9630))
    assert_equal(-20, rate.down(9620))
    assert_equal(-10, rate.down(9610))

  def test_down2(self):
    rate = Rate258Price(2)
    assert_equal(0, rate.down(0))
    assert_equal(0, rate.down(2))

    assert_equal(-2, rate.down(10))
    assert_equal(-2, rate.down(12))
    assert_equal(-3, rate.down(15))
    assert_equal(-3, rate.down(18))
    assert_equal(-2, rate.down(20))

    assert_equal(0, rate.down(33))

    rate = Rate258Price(3)
    assert_equal(0, rate.down(0))
    assert_equal(0, rate.down(10))
    assert_equal(0, rate.down(12))

    assert_equal(-2, rate.down(110))
    assert_equal(-2, rate.down(112))
    assert_equal(-3, rate.down(115))
    assert_equal(-3, rate.down(118))

