# encoding: UTF-8

import sys
import copy

import wx

from flexmock import flexmock
from nose.tools import *

from lib.gui_builder import GuiBuilderMixin
from tests.lib import MixinTestBase

class TestGuiBuilderMixin(MixinTestBase):
  testee_mixin = GuiBuilderMixin

  def test_BuildLabeledCtrl(self):
    sizer = flexmock()
    flexmock(wx.BoxSizer).new_instances(sizer)
    label = flexmock()
    flexmock(wx.StaticText).new_instances(label)
    sizer.should_receive('Add').with_args(label, 0, wx.ALIGN_CENTER_VERTICAL).ordered

    mock_builtin = flexmock(sys.modules['__builtin__'])
    mock_builtin.should_receive('eval').with_args("wx.TextCtrl").and_return(wx.TextCtrl).once
    mock_ctrl = flexmock()
    flexmock(wx.TextCtrl).new_instances(mock_ctrl)
    sizer.should_receive('Add').with_args(mock_ctrl, 1, int, int).ordered
    assert_equal(self.o.BuildLabeledCtrl('foo'), sizer)

  def test_BuildLabeledCtrl_with_more_args(self):
    sizer = flexmock()
    flexmock(wx.BoxSizer).new_instances(sizer).never

    label = flexmock()
    flexmock(wx.StaticText).new_instances(label)
    sizer.should_receive('Add').with_args(label, 0, wx.ALIGN_CENTER_VERTICAL).ordered

    mock_builtin = flexmock(sys.modules['__builtin__'])
    mock_builtin.should_receive('eval').with_args("wx.Choice").and_return(wx.Choice).once

    mock_ctrl = flexmock()
    flexmock(wx.Choice).new_instances(mock_ctrl)
    sizer.should_receive('Add').with_args(mock_ctrl, 1, int, int).ordered
    # FIXME: dont know why following codes don't work
    #class Handler:
      #def __call__(self, ctrl): pass
    #h = Handler()
    #flexmock(h).should_receive('__call__').with_args(mock_ctrl).once
    assert_equal(self.o.BuildLabeledCtrl('foo', sizer, "Choice"), sizer)

  def test_BuildCtrlByConfig_simple(self):
    sizer = flexmock()
    cfgs = (
      {'label': u'竞投牌号:'} ,
      {'label': u'姓名:'} ,
    )
    self.o.should_receive('BuildLabeledCtrl').with_args(**cfgs[0]).once
    self.o.should_receive('BuildLabeledCtrl').with_args(**cfgs[1]).once
    sizer.should_receive('Add').times(2)

    self.o.BuildCtrlsByConfig(sizer, cfgs)

  def test_BuildCtrlByConfig_complex(self):
    sizer = flexmock()
    cfgs = (
      {'label': u'竞投牌号:'} ,
      {'label': u'证件种类:', 'ctrl_type' : 'Choice'},
      {'label': u'证件号:', 'use_old_sizer': True, 'spacer': (20, 10)},
    )
    self.o.should_receive('BuildLabeledCtrl').with_args(**cfgs[0]).once
    sub_sizer = flexmock()
    self.o.should_receive('BuildLabeledCtrl').with_args(**cfgs[1]).and_return(sub_sizer).once

    sub_sizer.should_receive('AddSpacer').with_args((20, 10)).once
    cfg = copy.copy(cfgs[2])
    cfg.pop('use_old_sizer')
    cfg.pop('spacer')
    cfg['sizer'] = sub_sizer
    self.o.should_receive('BuildLabeledCtrl').with_args(**cfg).once
    sizer.should_receive('Add').times(2)

    self.o.BuildCtrlsByConfig(sizer, cfgs)


