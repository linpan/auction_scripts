# encoding: UTF-8

from flexmock import flexmock
from lib.mixin import MixIn, UnmixIn

class MixinTestBase:
  def setUp(self):
    self.o = flexmock()
    MixIn(self.o.__class__, self._GetTesteeMixin())

  def tearDown(self):
    UnmixIn(self.o.__class__, self._GetTesteeMixin())

  def _GetTesteeMixin(self):
    return self.testee_mixin and self.testee_mixin or eval(self.__class__.__name__[4:])


