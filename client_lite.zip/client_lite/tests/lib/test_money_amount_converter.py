# encoding: UTF-8

from lib.money_amount_converter import MoneyAmountConverter
from nose.tools import *

class TestMoneyAmountConverter:
  def test_convert_amount_less_than_thounds(self):
    assert_equal(MoneyAmountConverter.convert(1), u'壹元整')
    assert_equal(MoneyAmountConverter.convert(12), u'壹拾貳元整')
    assert_equal(MoneyAmountConverter.convert(123), u'壹佰貳拾參元整')
    assert_equal(MoneyAmountConverter.convert(1234), u'壹仟貳佰參拾肆元整')

    assert_equal(MoneyAmountConverter.convert(10), u'壹拾元整')
    assert_equal(MoneyAmountConverter.convert(100), u'壹佰元整')
    assert_equal(MoneyAmountConverter.convert(1000), u'壹仟元整')
    assert_equal(MoneyAmountConverter.convert(10000), u'壹萬元整')
    assert_equal(MoneyAmountConverter.convert(100000), u'壹拾萬元整')
    assert_equal(MoneyAmountConverter.convert(1000000), u'壹佰萬元整')
    assert_equal(MoneyAmountConverter.convert(10000000), u'壹仟萬元整')
    assert_equal(MoneyAmountConverter.convert(100000000), u'壹億元整')

    assert_equal(MoneyAmountConverter.convert(120), u'壹佰貳拾元整')
    assert_equal(MoneyAmountConverter.convert(103), u'壹佰零參元整')
    assert_equal(MoneyAmountConverter.convert(1004), u'壹仟零肆元整')
    assert_equal(MoneyAmountConverter.convert(1040), u'壹仟零肆拾元整')
    assert_equal(MoneyAmountConverter.convert(1400), u'壹仟肆佰元整')
    assert_equal(MoneyAmountConverter.convert(1401), u'壹仟肆佰零壹元整')
    assert_equal(MoneyAmountConverter.convert(1034), u'壹仟零參拾肆元整')

    assert_equal(MoneyAmountConverter.convert(10004), u'壹萬零肆元整')
    assert_equal(MoneyAmountConverter.convert(10040), u'壹萬零肆拾元整')
    assert_equal(MoneyAmountConverter.convert(10400), u'壹萬零肆佰元整')
    assert_equal(MoneyAmountConverter.convert(14000), u'壹萬肆仟元整')

    assert_equal(MoneyAmountConverter.convert(12345), u'壹萬貳仟參佰肆拾伍元整')
    assert_equal(MoneyAmountConverter.convert(13034), u'壹萬參仟零參拾肆元整')
    assert_equal(MoneyAmountConverter.convert(130034), u'壹拾參萬零參拾肆元整')
    assert_equal(MoneyAmountConverter.convert(1301034), u'壹佰參拾萬壹仟零參拾肆元整')
    assert_equal(MoneyAmountConverter.convert(1031034), u'壹佰零參萬壹仟零參拾肆元整')

    assert_equal(MoneyAmountConverter.convert(101031034), u'壹億零壹佰零參萬壹仟零參拾肆元整')
    assert_equal(MoneyAmountConverter.convert(100000034), u'壹億零參拾肆元整')
    assert_equal(MoneyAmountConverter.convert(100000004), u'壹億零肆元整')
    assert_equal(MoneyAmountConverter.convert(10300000004), u'壹佰零參億零肆元整')
