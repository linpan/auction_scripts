# encoding: UTF-8

from flexmock import flexmock
from nose.tools import *

from lib.base_reg_num_list_ctrl import BaseRegNumListCtrlMixin
import lib.base_reg_num_list_ctrl as ctrl_mod
from tests.lib import MixinTestBase

class TestBaseRegNumListCtrlMixin(MixinTestBase):
  testee_mixin = BaseRegNumListCtrlMixin

  def test_LoadRegNumData_with_empty_data(self):
    result = {'results': []}
    flexmock(ctrl_mod).should_receive('get').with_args('/activity/1/reg_nums')\
        .and_return(result).once
    self.o.should_receive('act_id').and_return(1).once
    assert_equal(self.o.LoadRegNumData(), [])

  def test_LoadRegNumData_with_normal_data(self):
    result = {'keys': ['id', 'num', 'agent', 'activity_id', 'buyer_name'],
              'results': [(1, 1, 0, 1, None), (2, 2, 1, 1, u'vincent')]}
    flexmock(ctrl_mod).should_receive('get').with_args('/activity/1/reg_nums')\
        .and_return(result).once
    self.o.should_receive('act_id').and_return(1).once
    assert_equal(self.o.LoadRegNumData(),
                 [{'id': 1, 'num': 1, 'agent': 0, 'activity_id': 1,
                   'buyer_name': None},
                  {'id': 2, 'num': 2, 'agent': 1, 'activity_id': 1,
                   'buyer_name': u'vincent'},
                 ])
