# encoding: UTF-8

import sys

from flexmock import flexmock
from nose.tools import *
import wx

from lib.mixin import MixIn, UnmixIn

import reg_num_management.reg_num_list_ctrl as ctrl_mod
from reg_num_management.reg_num_list_ctrl import RegNumListCtrlMixin
from reg_num_management.reg_num_input_dlg import RegNumInputDlg

class TestRegNumListCtrlMixin:
  def setUp(self):
    self.o = flexmock()
    MixIn(self.o.__class__, RegNumListCtrlMixin)

  def tearDown(self):
    UnmixIn(self.o.__class__, RegNumListCtrlMixin)

  def test_GetRegNums(self):
    dlg = flexmock(min_value=1, max_value=2)
    flexmock(RegNumInputDlg).new_instances(dlg)
    dlg.should_receive('CenterOnScreen').once
    dlg.should_receive('ShowModal').once
    assert_equal(self.o.GetRegNums("foobar"), (1,2))

  def test_PopulateData(self):
    self.o.should_receive('InsertStringItem').with_args(sys.maxint,
                                                        '1').and_return(1).once
    self.o.should_receive('InsertStringItem').with_args(sys.maxint,
                                                        '2').and_return(2).once
    self.o.should_receive('SetStringItem').with_args(1, 1, u'是').once
    self.o.should_receive('SetStringItem').with_args(2, 1, u'否').once
    self.o.should_receive('SetItemData').with_args(1, 1).once
    self.o.should_receive('SetItemData').with_args(2, 2).once
    self.o.should_receive('Refresh').once

    self.o.PopulateData([{'num':1, 'agent' : 1, 'id': 1},
                         {'num':2, 'agent': 0, 'id': 2}])

