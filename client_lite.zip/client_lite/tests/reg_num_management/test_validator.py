# encoding: UTF-8

from flexmock import flexmock
from nose.tools import *

import wx

import reg_num_management.validator as validator
from reg_num_management.validator import RegNumsValidatorMixIn

from lib.mixin import MixIn, UnmixIn

class TestRegNumsValidatorMixin:
  def setUp(self):
    self.o = flexmock()
    MixIn(self.o.__class__, RegNumsValidatorMixIn)

  def tearDown(self):
    UnmixIn(self.o.__class__, RegNumsValidatorMixIn)

  def test_DoValidate(self):
    ctrl1 = flexmock()
    ctrl2 = flexmock()
    dlg = flexmock(min_text_ctrl=ctrl1, max_text_ctrl=ctrl2)
    self.o.should_receive('CheckValidDigit').with_args(ctrl1).and_return(False).once
    self.o.should_receive('CheckValidDigit').with_args(ctrl2).never
    self.o.should_receive('CheckValidRange').never
    assert_false(self.o.DoValidate(dlg))

  def test_DoValidate2(self):
    ctrl1 = flexmock()
    ctrl2 = flexmock()
    dlg = flexmock(min_text_ctrl=ctrl1, max_text_ctrl=ctrl2)
    self.o.should_receive('CheckValidDigit').with_args(ctrl1).and_return(True).once
    self.o.should_receive('CheckValidDigit').with_args(ctrl2).and_return(True).once
    self.o.should_receive('CheckValidRange').with_args(ctrl1,
                                                       ctrl2).and_return(False).once
    assert_false(self.o.DoValidate(dlg))


  def test_DoValidate3(self):
    ctrl1 = flexmock()
    ctrl2 = flexmock()
    dlg = flexmock(min_text_ctrl=ctrl1, max_text_ctrl=ctrl2)
    self.o.should_receive('CheckValidDigit').with_args(ctrl1).and_return(True).once
    self.o.should_receive('CheckValidDigit').with_args(ctrl2).and_return(True).once
    self.o.should_receive('CheckValidRange').with_args(ctrl1,
                                                       ctrl2).and_return(True).once
    assert_true(self.o.DoValidate(dlg))

  def test_CheckValidRange(self):
    ctrl1 = flexmock(GetValue=lambda: "1")
    ctrl2 = flexmock(GetValue=lambda: "2")
    flexmock(wx).should_receive('MessageBox').never
    assert_true(self.o.CheckValidRange(ctrl1, ctrl2))

  def test_CheckValidRange2(self):
    ctrl1 = flexmock(GetValue=lambda: "2")
    ctrl2 = flexmock(GetValue=lambda: "1")
    flexmock(wx).should_receive('MessageBox').once
    assert_false(self.o.CheckValidRange(ctrl1, ctrl2))

  def test_CheckValidDigit(self):
    ctrl = flexmock(GetValue=lambda: "123a")
    flexmock(wx).should_receive('MessageBox').once
    self.o.should_receive('MarkError').with_args(ctrl).once
    assert_false(self.o.CheckValidDigit(ctrl))

  def test_CheckValidDigit2(self):
    ctrl = flexmock(GetValue=lambda: "123")
    flexmock(wx).should_receive('MessageBox').never
    self.o.should_receive('MarkError').with_args(ctrl).never
    self.o.should_receive('Restore').with_args(ctrl).once
    assert_true(self.o.CheckValidDigit(ctrl))

    ctrl = flexmock(GetValue=lambda: "0123")
    self.o.should_receive('Restore').with_args(ctrl).once
    assert_true(self.o.CheckValidDigit(ctrl))
