#!/user/bin/env python
# -*- coding:utf-8 -*-
# RESTful Web API

import time
from threading import Thread
import subprocess
import wx
import threading
from config import verification_server_info
from config import web_live_server_info
from auction_live.post_bid_data import VerificationDataPoster, LiveDataPoster
from auction_live.live_redis_client import clear_redis
try:
    from wx.lib.pubsub import setuparg1
    from wx.lib.pubsub import pub

except ImportError:
    from wx.lib.pubsub import Publisher as pub


class PostThread(Thread):
    """Thread Class."""

    # ----------------------------------------------------------------------
    def __init__(self, flag=None):
        """Init Worker Thread Class."""
        Thread.__init__(self)
        self.flag = flag
        self._stopevent = threading.Event()
        self.start()  # start the thread

    # ----------------------------------------------------------------------
    def run(self):
        """Run Worker Thread."""
        if self.flag:
            p = VerificationDataPoster(
                    verification_server_info['host'],
                    verification_server_info.get('user', None),
                    verification_server_info.get('passwd', None))
            interval = 5
        else:
            p = LiveDataPoster(web_live_server_info['host'],
                               web_live_server_info.get('user', None),
                               web_live_server_info.get('passwd', None))
            interval = None

        try:
            p.run(interval)
            wx.CallAfter(self.update_view)
        except Exception as e:
            print "{ verify }Got unexpected error:% " % e
    def kill_thread(self):
        self._stopevent.set()


class RestfulApi(wx.Frame):

    def __init__(self, *args, **kwargs):
        super(RestfulApi, self).__init__(*args, **kwargs)

        self.init_ui()
        self.Show()

    def init_ui(self):

        self.panel = MainPanel(self)

        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(self.panel, 1, wx.EXPAND)
        self.SetSizer(sizer)
        self.Center()


class MainPanel(wx.Panel):
    """"""

    def __init__(self, parent):
        self.ui_font = None
        wx.Panel.__init__(self, parent)

        sizer = wx.BoxSizer(wx.HORIZONTAL)

        inner_sizer = wx.StaticBoxSizer(
            wx.StaticBox(self, label=u'服务启动区'), wx.VERTICAL)
        post_sizer = wx.GridSizer(3, 1, 10, 10)
        # 负责本地oa的按钮 tb=ToggleButton
        oa_tb = wx.ToggleButton(self, label=u'post本地')
        post_sizer.Add(oa_tb, 1, wx.ALL | wx.EXPAND, 5)
        # 负责竞投直播的按钮
        bid_tb = wx.ToggleButton(self, label=u'post竞投')
        post_sizer.Add(bid_tb, 1, wx.ALL | wx.EXPAND, 5)
        # redis_tb 清除换成按钮
        redis_tb = wx.ToggleButton(self, label=u'清除缓冲')
        post_sizer.Add(redis_tb, 1, wx.ALL | wx.EXPAND, 5)

        inner_sizer.Add(post_sizer, 0, wx.ALL | wx.EXPAND, 5)
        sizer.Add(inner_sizer, 1, wx.EXPAND)

        bottom_sizer = wx.StaticBoxSizer(
            wx.StaticBox(self, label=u'服务状态区'), wx.HORIZONTAL)
        self.txt_btn = wx.StaticText(self, label=' ')

        bottom_sizer.Add(self.txt_btn, 2, wx.ALL, 5)

        sizer.Add(bottom_sizer, 1, wx.EXPAND)
        oa_tb.Bind(wx.EVT_TOGGLEBUTTON, self.on_local_post)
        bid_tb.Bind(wx.EVT_TOGGLEBUTTON, self.on_web_post)
        redis_tb.Bind(wx.EVT_TOGGLEBUTTON, self.clear_posts_redis)
        self._defaultfont()
        self.SetSizer(sizer)

    def on_local_post(self, evt):

        obj = evt.GetEventObject()
        is_pressed = obj.GetValue()
        if is_pressed:

            txt = u'本地post服务准备启动...'
            if self.txt_btn.GetLabel():
                txt = self.txt_btn.GetLabel()+'\n'+u'本地post服务准备启动...'
            self.txt_btn.SetLabel(txt)
            PostThread(flag=True)


    def on_web_post(self, evt):
        obj = evt.GetEventObject()
        print obj.GetLabel()
        is_pressed = obj.GetValue()
        # cmd = ["python", "../auction_live/post_bid_data.py"]
        if is_pressed:
            txt = u'竞投直播服务启动...'
            if self.txt_btn.GetLabel():
                txt = self.txt_btn.GetLabel() + '\n' + u'竞投直播服务启动...'
            self.txt_btn.SetLabel(txt)
            PostThread()
            # time.sleep(10)
            # p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            # while True:
            #     line = p.stdout.readline()
            #     if not line:
            #         break
            #     print(line)

    def clear_posts_redis(self, evt):
        dlg = wx.MessageDialog(None, u"你确定要清理缓存数据吗?", u'警告信息!!!', wx.YES_NO | wx.ICON_QUESTION)
        result = dlg.ShowModal()
        if result == wx.ID_OK:
            clear_redis()
        dlg.Destroy()


    def _defaultfont(self):
        """
        对子窗口的字体配置
        :return:
        """
        # under wxWindowList see
        # http://docs.wxwidgets.org/3.0/classwx_window.html
        wxWindowList = self.GetChildren()
        if not self.ui_font:
            # TODO INSTALL YAHEI FONT FOR MAC
            self.ui_font = wx.Font(
                14,
                wx.DEFAULT,
                wx.NORMAL,
                wx.NORMAL,
                False,
                u'微软雅黑')
        for win in wxWindowList:
            win.SetFont(self.ui_font)


def main():
    app = wx.App()
    RestfulApi(None, title=u'服务配置面板', size=(400, 300))
    app.MainLoop()


if __name__ == '__main__':
    main()
