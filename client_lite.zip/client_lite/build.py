import glob
import os
import sys
import shutil
import subprocess

apps = ('launcher', 'activity_management', 'sub_activity_management',
        'registration', 'reg_num_management', 'settlement', 'admin',
        'verification', 'buyer_management')
#apps = ('launcher', 'activity_management')

dirs = ('dist', 'data')
for dir in dirs:
  if not os.path.exists(dir):
    os.mkdir(dir)

for app in apps:
  os.chdir(app)
  if not os.path.exists('dist'):
    os.mkdir('dist')
  subprocess.call(['python', 'setup.py', 'py2exe'])
  os.chdir('..')
  subprocess.call(['cp', app+'/dist/*', 'dist'])

subprocess.call(['cp', 'config.dat', 'dist'])
subprocess.call(['cp', '-r', 'assets', 'dist'])


print "start to build installer ..."
subprocess.call(['makensis', 'auction.nsi'])
print "Done"
