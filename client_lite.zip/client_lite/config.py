# encoding: UTF-8

import os
import sys

from lib import countries

time_fmt = "%Y-%m-%d %H:%M:%S"

_logger = None

identity_choices = (u'身份证', u'护照', u'军官证', u'其它')
country_choices = countries.get_country_list()

def log_last_exception(msg):
  err_msg = msg + " %s " % sys.exc_info()[1].message
  get_logger().error(err_msg)
  print err_msg

def get_logger(name=None):
  global _logger
  if _logger is None:
    import logging
    _logger = logging.getLogger(name)
    assert(name != None)
    hdlr_name = os.path.join(root_path(), "%s.log" % name)
    hdlr = logging.FileHandler(hdlr_name)
    formater = logging.Formatter('%(asctime)s|%(process)d|%(levelname)s|%(message)s')
    hdlr.setFormatter(formater)
    _logger.addHandler(hdlr)
    _logger.setLevel(logging.INFO)
  return _logger

def is_frozen():
  return hasattr(sys, 'frozen')

def root_path():
  if is_frozen():
    return os.path.dirname(os.path.abspath(unicode(sys.executable,
                                   sys.getfilesystemencoding())))
  return os.path.dirname(os.path.abspath(
    unicode(__file__, sys.getfilesystemencoding())))

base_dir = root_path()
asset_dir = os.path.join(base_dir, 'assets')
img_dir = os.path.join(asset_dir, 'images')
packages_dir = os.path.join(base_dir, 'packages')

card_photo_dir = os.path.join(base_dir, 'data', 'card', 'photos')
if not os.path.exists(card_photo_dir): os.makedirs(card_photo_dir)

idr_base_dir = os.path.join(packages_dir, 'idr')

convert_img_on_fly = False
# enable_navigation = False
# enable_edit_antique = False
enable_navigation = True
enable_edit_antique = True

buyer_bill_rows_per_page = 20
seller_bill_rows_per_page = 16

#base_service_url = 'http://localhost:8080'
#base_service_url = 'http://192.168.1.10:8080'
with open(os.path.join(base_dir, "config.dat"), "r") as f:
  for line in f.readlines():
    exec(line)

auctioneers = [u'黄巾美', u'王刚', u'郁静瑜', u'赵慧']
operators = [u'李雪娇', u'赵鑫']

live_redis_host = '127.0.0.1'
live_redis_port = 6379

sub_act_id_mapping = {

    187: 1,   # 中国书画（一）
    188: 2,   # 中国书画（二）
    189: 3,   # 现当代艺术
    190: 4,   # 瓷器
    191: 5,   # 机制币
    192: 6,   # 邮品
    193: 7    # 纸币
}
