# encoding: UTF-8

import wx
import wx.lib.intctrl

class DealConfirmDlg(wx.Dialog):
  def __init__(self, parent):
    wx.Dialog.__init__(self, parent)

    sizer = wx.BoxSizer(wx.VERTICAL)

    line_sizer = wx.BoxSizer(wx.HORIZONTAL)
    line_sizer.Add(wx.StaticText(self, label=u'买家竞投牌号:'), 0, wx.ALL, 5)

    line_sizer.Add(wx.lib.intctrl.IntCtrl(self, name=u'reg_num'), 0, wx.ALL, 5)
    sizer.Add(line_sizer, 0, wx.ALL|wx.EXPAND, 5)

    sizer.Add(self.CreateStdDialogButtonSizer(wx.OK|wx.CANCEL),
              0, wx.ALL|wx.ALIGN_CENTER_HORIZONTAL, 5)
    self.SetSizerAndFit(sizer)

    self.Center()

  def GetRegNum(self):
    return self.FindWindowByName(u'reg_num').GetValue()
