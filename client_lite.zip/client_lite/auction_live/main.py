#!/user/bin/python
# -*- coding:utf-8 -*-
# main.py
# 现场投影程序入口
# editor at 01/08 2018
#  custom function with lower letter by pep8 rules
# 自定义函数命名根据pep8规则， 一律采用小写

import copy

from wx.lib.intctrl import IntCtrl
import wx.lib.buttons as buttons

from lib.bitmap_button_ex import BitmapButtonEx
from lib.rate_258_price import Rate258Price
from lib.img_utils import img_scale
from lib.utils import *

import db
import live_redis_client as live_redis

from slide import SlideFrame
# 以下定义了三个对话框
from sub_act_config_dlg import SubActConfigDlg
from deal_confirm_dlg import DealConfirmDlg
from change_antique_info_dlg import ChangeAntInfoDlg

from config import enable_navigation

from common import *

import sys
reload(sys)
sys.setdefaultencoding('utf-8')


class AuctionLiveApp(wx.App):
    """
    实现了拍卖系统主窗口逻辑
    """

    def OnInit(self):
        self.act = db.GetActiveActivity()  # 获得最新一届的拍卖会 eg:2018s拍卖会
        if not self.act:
            wx.MessageBox(u'请创建拍卖会', u'错误信息', style=wx.ICON_ERROR | wx.OK)
            return False
        act_name = self.act['name'].decode('utf-8')
        self.frame = MainFrame(None,
                               title=u'%s' % act_name,
                               size=(1024, 768))

        self.SetTopWindow(self.frame)
        self.frame.Show()
        return True


class MainFrame(wx.Frame):
    """"""

    def __init__(self, *args, **kwargs):
        super(MainFrame, self).__init__(*args, **kwargs)

        # 定义投影的窗口
        self.slide_frame = SlideFrame(None, title=u'投影窗口', size=(1024, 768))
        # 开启或者隐藏 投影窗口
        self.slide_frame.Show()
        # self.slide_frame.Hide()

        self.Bind(wx.EVT_CLOSE, self.on_close_window)

        self.panel = MainPanel(self)

        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(self.panel, 1, wx.EXPAND)
        self.SetSizer(sizer)
        self.Center()

    def on_close_window(self, evt):
        try:
            self.slide_frame.Destroy()
        except Exception as e:
            # 如果直接从投影窗口关闭就会异常
            print u'关闭投影窗口异常信息%s' % e

        self.Destroy()


class MainPanel(wx.Panel):
    """"""

    def __init__(self, parent):
        wx.Panel.__init__(self, parent)

        self.delta_price = 0
        self.cur_price = 0
        self.rate2 = Rate258Price(2)
        self.rate3 = Rate258Price(3)

        self.price_btns = []
        self.cur_lot_id = None
        self.cur_antique_id = None
        self.cur_price_id = None

        # TODO 两个变量的含义
        self.initial_price_id = None  # 起拍价格 当前拍品区的加价
        self.init_price_input_id = None  # 加价区的输入价格

        self.lot_locator_id = None   # 定位图录号
        # TODO ?
        self.bmp_static = None  # 图片展示区对象变量 wx.StaticBitmap
        self.default_antique_image = os.path.join(img_dir, 'antique_placeholder.jpg')

        # app = wx.GetApp()
        self.act = wx.GetApp().act
        assert self.act is not None
        self.sub_act = None
        self.antique = None

        self.cur_antique_input_id = None
        self.change_ant_btn_id = None

        self.reward_percent = 15
        self.exchange_rate = {}

        # Layout in here
        sizer = wx.BoxSizer(wx.VERTICAL)
        # --------------
        # |      |     |
        # |______|____ |
        # tow in one box
        top_sizer = wx.BoxSizer(wx.HORIZONTAL)
        # 2/5 -> 5/10 实现了合理的布局
        top_sizer.Add(self.price_control(), 5, wx.ALL | wx.EXPAND, 5)
        top_sizer.Add(self.antique_image(), 10, wx.ALL | wx.EXPAND, 5)
        sizer.Add(top_sizer, 3, wx.ALL | wx.EXPAND, 5)

        # bottom layout
        bot_sizer = wx.BoxSizer(wx.HORIZONTAL)
        bot_sizer.Add(self.operation_control(), 1, wx.ALL | wx.EXPAND, 5)
        bot_sizer.Add(self.summary_info(), 1, wx.ALL | wx.EXPAND, 5)
        bot_sizer.Add(self.cur_antique_info(), 1, wx.ALL | wx.EXPAND, 5)
        sizer.Add(bot_sizer, 2, wx.ALL | wx.EXPAND)

        self.SetSizer(sizer)
        self.reset()
        self.update_font()
        # 在Frame创建完毕之后才会被调用
        wx.CallAfter(self._config_sub_act)

        self.SetSizer(sizer)

    def reset(self):
        """"""

        self.cur_price = 0

        # reset gui controls
        init_price_input = self.FindWindowById(self.init_price_input_id)
        init_price_input.Clear()
        # 获得焦点
        init_price_input.SetFocus()
        self.FindWindowById(self.cur_price_id).SetLabel('--')
        self.FindWindowById(self.initial_price_id).SetLabel('--')

    def price_control(self):
        """
        加价区
        :return: sizer
        """
        box = wx.StaticBox(self, label=u'加价金额')
        sizer = wx.StaticBoxSizer(box, wx.VERTICAL)
        btn_sizer = wx.GridSizer(5, 2, 5, 5)

        # TODO 给togglebutton设置大小不生效？
        for btn_txt in (u'100万', u'50万', u'10万', u'5万', u'1万',
                        u'5000', u'1000', u'500', u'100', u'2位258'):
            btn = wx.ToggleButton(self, id=wx.ID_ANY, label=btn_txt)  # default size=(84,21)

            btn_sizer.Add(btn, 0, wx.ALL|wx.EXPAND)
            self.Bind(wx.EVT_TOGGLEBUTTON, self.handle_delta_price, btn)
            self.price_btns.append(btn)

        sizer.Add(btn_sizer, 1, wx.ALL | wx.EXPAND, 10)

        line_sizer = wx.BoxSizer(wx.HORIZONTAL)
        line_sizer.Add(wx.StaticText(self, label=u'拍品起拍价:'),
                       0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 3)

        self.init_price_input_id = wx.NewId()
        #  numeric text 接受回车键
        init_price_text = IntCtrl(
            self, self.init_price_input_id, style=wx.TE_PROCESS_ENTER)
        line_sizer.Add(init_price_text, 1, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 3)
        self.Bind(wx.EVT_TEXT_ENTER, self.handle_init_price, init_price_text)
        line_sizer.Add(wx.StaticText(self, label=u'元'), 0,
                       wx.ALL | wx.ALIGN_CENTER_VERTICAL, 3)

        sizer.Add(line_sizer, 0, wx.ALL | wx.EXPAND, 5)

        return sizer

    def cur_antique_info(self):
        """
        当前拍品信息
        :return: sizer
        """

        box = wx.StaticBox(self, label=u'当前拍品信息')
        sizer = wx.StaticBoxSizer(box, wx.VERTICAL)

        line_sizer = wx.BoxSizer(wx.HORIZONTAL)
        line_sizer.Add(
            wx.StaticText(
                self,
                label=u'LOT:'),
            0,
            wx.ALL | wx.ALIGN_RIGHT,
            3)
        # 采用自动生产的id，而非手动设置id的值，避免重复
        self.cur_lot_id = wx.NewId()
        line_sizer.Add(
            wx.StaticText(
                self,
                self.cur_lot_id,
                label=u'--',
                name=u'antique_lot'),
            0,
            wx.ALL,
            0)
        sizer.Add(line_sizer, 1, wx.ALL | wx.EXPAND, 3)

        # 拍品名称
        line_sizer = wx.BoxSizer(wx.HORIZONTAL)
        line_sizer.Add(
            wx.StaticText(
                self,
                label=u'名称:'),
            0,
            wx.ALL | wx.ALIGN_RIGHT,
            3)
        # 采用自动生产的id，而非手动设置id的值，避免重复
        self.cur_antique_id = wx.NewId()
        line_sizer.Add(
            wx.StaticText(
                self,
                self.cur_antique_id,
                label=u'--',
                name=u'antique_name'),
            0,
            wx.ALL,
            0)
        sizer.Add(line_sizer, 1, wx.ALL | wx.EXPAND, 3)

        # 是否允许编辑拍品名称
        if config.enable_edit_antique:
            self.cur_antique_input_id = wx.NewId()

            line_sizer = wx.BoxSizer(wx.HORIZONTAL)
            self.change_ant_btn_id = wx.NewId()
            change_btn = wx.Button(
                self, self.change_ant_btn_id, label=u'修改拍品名称')
            self.Bind(wx.EVT_BUTTON, self.change_antique_info, change_btn)
            line_sizer.Add(change_btn, 0, wx.ALL, 3)

            # TODO delete a line code ?
            sizer.Add(line_sizer, 1, wx.ALL | wx.EXPAND, 3)

        # 当前价格 区
        line_sizer = wx.BoxSizer(wx.HORIZONTAL)
        line_sizer.Add(
            wx.StaticText(
                self,
                label=u'当前价格:'),
            0,
            wx.ALL | wx.ALIGN_RIGHT,
            3)
        self.cur_price_id = wx.NewId()
        line_sizer.Add(
            wx.StaticText(
                self,
                self.cur_price_id,
                label=u'--'),
            0,
            wx.ALL | wx.ALIGN_RIGHT,
            3)
        sizer.Add(line_sizer, 1, wx.ALL | wx.EXPAND, 3)
        # 起拍价格 区
        line_sizer = wx.BoxSizer(wx.HORIZONTAL)
        line_sizer.Add(
            wx.StaticText(
                self,
                label=u'起拍价格:'),
            0,
            wx.ALL | wx.ALIGN_RIGHT,
            3)
        self.initial_price_id = wx.NewId()
        line_sizer.Add(
            wx.StaticText(
                self,
                self.initial_price_id,
                label=u'--'),
            0,
            wx.ALL | wx.ALIGN_RIGHT,
            3)
        sizer.Add(line_sizer, 1, wx.ALL | wx.EXPAND, 3)

        return sizer

    def operation_control(self):
        box = wx.StaticBox(self, label=u'操作区')
        sizer = wx.StaticBoxSizer(box, wx.VERTICAL)
        top_sizer = wx.BoxSizer(wx.HORIZONTAL)
        # 成交按钮的定义
        dealed_id = wx.NewId()
        btn = buttons.GenButton(
            self,
            label=u'成交(Y)',
            id=dealed_id,
            size=(
                90,
                50))
        top_sizer.Add(btn, 0, wx.ALL | wx.EXPAND, 5)
        self.Bind(wx.EVT_BUTTON, self.handle_dealed, btn)
        # 流拍按钮的定义
        missed_id = wx.NewId()
        btn = buttons.GenButton(
            self,
            label=u'流拍(N)',
            id=missed_id,
            size=(
                90,
                50))
        top_sizer.Add(btn, 0, wx.ALL | wx.EXPAND, 5)
        self.Bind(wx.EVT_BUTTON, self.handle_missed, btn)
        # 撤怕按钮的定义
        cancelled_id = wx.NewId()
        btn = buttons.GenButton(
            self,
            label=u'撤拍(C)',
            id=cancelled_id,
            size=(
                90,
                50))
        top_sizer.Add(btn, 0, wx.ALL | wx.EXPAND, 5)
        self.Bind(wx.EVT_BUTTON, self.handle_canceled, btn)
        sizer.Add(top_sizer, 0, wx.EXPAND | wx.ALL |
                  wx.ALIGN_CENTER_HORIZONTAL, 5)

        # up down 箭头的定义
        middle_sizer = wx.BoxSizer(wx.HORIZONTAL)
        arrow_left_id = wx.NewId()
        # TODO 可以左右合并一个判断语句里
        if enable_navigation:
            btn = BitmapButtonEx('arrow-left.ico', self, id=arrow_left_id)
            self.Bind(wx.EVT_BUTTON, self.handle_pre_antique, btn)
            middle_sizer.Add(btn, 0, wx.ALL, 15)

        arrow_up_id = wx.NewId()
        btn = BitmapButtonEx('arrow-up.png', self, id=arrow_up_id)
        self.Bind(wx.EVT_BUTTON, self.handle_price_up, btn)
        middle_sizer.Add(btn, 0, wx.ALL, 15)

        arrow_down_id = wx.NewId()
        btn = BitmapButtonEx('arrow-down.png', self, id=arrow_down_id)
        self.Bind(wx.EVT_BUTTON, self.handle_price_down, btn)
        middle_sizer.Add(btn, 0, wx.ALL, 15)

        arrow_right_id = wx.NewId()
        if enable_navigation:
            btn = BitmapButtonEx('arrow-right.ico', self, id=arrow_right_id)
            self.Bind(wx.EVT_BUTTON, self.handle_next_antique, btn)
            middle_sizer.Add(btn, 0, wx.ALL, 15)

        sizer.Add(middle_sizer, 0, wx.ALL | wx.ALIGN_CENTER_HORIZONTAL, 5)

        top_window = self.GetTopLevelParent()
        # 菜单 事件
        top_window.Bind(wx.EVT_MENU, self.handle_dealed, id=dealed_id)
        top_window.Bind(wx.EVT_MENU, self.handle_missed, id=missed_id)
        top_window.Bind(wx.EVT_MENU, self.handle_canceled, id=cancelled_id)
        top_window.Bind(wx.EVT_MENU, self.handle_price_up, id=arrow_up_id)
        top_window.Bind(wx.EVT_MENU, self.handle_price_down, id=arrow_down_id)

        # reg_hot_keys 快捷键
        reg_hot_keys = [
            (wx.ACCEL_ALT, ord('Y'), dealed_id),
            (wx.ACCEL_ALT, ord('N'), missed_id),
            (wx.ACCEL_ALT, ord('C'), cancelled_id),
            (wx.ACCEL_NORMAL, wx.WXK_LEFT, arrow_left_id),
            (wx.ACCEL_NORMAL, wx.WXK_RIGHT, arrow_right_id)
        ]
        if not config.enable_edit_antique:
            reg_hot_keys.append((wx.ACCEL_NORMAL, wx.WXK_UP, arrow_up_id))
            reg_hot_keys.append(
                (wx.ACCEL_NORMAL, wx.WXK_RIGHT, arrow_right_id))

        accel_keys = wx.AcceleratorTable(reg_hot_keys)
        top_window.SetAcceleratorTable(accel_keys)

        # 分隔线
        seperator_line = wx.StaticLine(self)
        sizer.Add(seperator_line, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 10)
        # 图录号 区
        line_sizer = wx.BoxSizer(wx.HORIZONTAL)
        line_sizer.Add(wx.StaticText(self, label=u'图录号:'), 0,
                       wx.ALL | wx.ALIGN_CENTER_VERTICAL, 3)
        self.lot_locator_id = wx.NewId()
        # 定义只接受int输入，返回int(在键盘操作中，只能使用数字键)
        int_ctrl = wx.lib.intctrl.IntCtrl(
            self, id=self.lot_locator_id, style=wx.TE_PROCESS_ENTER)
        line_sizer.Add(int_ctrl, 1, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 3)
        self.Bind(wx.EVT_TEXT_ENTER, self.handle_lot_location, int_ctrl)
        # 拍品定位 区
        btn = buttons.GenButton(self, label=u'拍品定位')
        line_sizer.Add(btn, 0, wx.ALL, 3)
        self.Bind(wx.EVT_BUTTON, self.handle_lot_location, btn)
        sizer.Add(line_sizer, 0, wx.TOP | wx.ALIGN_CENTER_HORIZONTAL, 5)

        return sizer

    def antique_image(self):
        """
        拍品图片展示区
        :return: panel
        """
        panel = wx.Panel(self)
        # 定义两张图片展示框架
        sizer = wx.BoxSizer(wx.VERTICAL)
        hsizer = wx.BoxSizer(wx.HORIZONTAL)
        antique_bmp = wx.Bitmap(
            self.default_antique_image,
            wx.BITMAP_TYPE_JPEG)
        size = (antique_bmp.GetWidth() + 2, antique_bmp.GetHeight() + 2)
        self.bmp_static = wx.StaticBitmap(panel, wx.ID_ANY, antique_bmp, style=wx.BORDER_SIMPLE, size=size)
        hsizer.Add(self.bmp_static, 1, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 1)
        sizer.Add(hsizer, 1, wx.ALIGN_CENTER_HORIZONTAL)
        #  这方法跟 SetSizer() 差不多，此外它将把大小通告给窗口，以确保所有按钮都将显示在窗口上。
        panel.SetSizerAndFit(sizer)

        return panel
    # TODO 是否还保留这个函数

    def config_control(self):
        """
        实在不知道哪里用到此函数
        handle_lot_location
        :return: sizer

        """

        box = wx.StaticBox(self, label=u'选项')
        sizer = wx.StaticBoxSizer(box, wx.VERTICAL)

        top_sizer = wx.BoxSizer(wx.HORIZONTAL)
        top_sizer.Add(wx.StaticText(self, label=u'专场选择:'), 0, wx.ALL, 5)
        choices = []
        top_sizer.Add(wx.Choice(self, choices=choices), 0, wx.ALL, 5)
        sizer.Add(top_sizer, 0, wx.ALL | wx.EXPAND, 5)

        line_sizer = wx.BoxSizer(wx.HORIZONTAL)
        line_sizer.Add(wx.StaticText(self, label=u'LOT:'), 0,
                       wx.ALL | wx.ALIGN_CENTER_VERTICAL, 3)
        self.lot_locator_id = wx.NewId()
        txt_ctrl = wx.lib.intctrl.IntCtrl(
            self, id=self.lot_locator_id, style=wx.TE_PROCESS_ENTER)
        line_sizer.Add(txt_ctrl, 1, wx.ALL, 3)
        self.Bind(wx.EVT_TEXT_ENTER, self.handle_lot_location, txt_ctrl)

        btn = buttons.GenButton(self, label=u'拍品定位2')
        line_sizer.Add(btn, 0, wx.ALL, 3)
        self.Bind(wx.EVT_BUTTON, self.handle_lot_location, btn)
        sizer.Add(line_sizer, 0, wx.TOP | wx.ALIGN_CENTER_HORIZONTAL, 5)

        return sizer

    def summary_info(self):
        """
        交易汇总信息 区
        :return: sizer
        """
        box = wx.StaticBox(self, label=u'汇总信息')
        sizer = wx.StaticBoxSizer(box, wx.VERTICAL)

        # 拍品总数 区
        line_sizer = wx.BoxSizer(wx.HORIZONTAL)
        line_sizer.Add(wx.StaticText(self, label=u'拍品总数:'), 0, wx.ALL | wx.ALIGN_RIGHT, 3)
        line_sizer.Add(wx.StaticText(self, label=u'--', name=u'summary_total_count'), 0, wx.ALL, 3)
        sizer.Add(line_sizer, 1, wx.ALL | wx.EXPAND, 3)

        # 成交数量 区
        line_sizer = wx.BoxSizer(wx.HORIZONTAL)
        line_sizer.Add(wx.StaticText(self, label=u'成交件数:'), 0, wx.ALL | wx.ALIGN_RIGHT, 3)
        line_sizer.Add(wx.StaticText(self, label=u'--', name=u'summary_dealed_count'), 0, wx.ALL, 3)
        sizer.Add(line_sizer, 1, wx.ALL | wx.EXPAND, 3)

        # 总成交价 区
        line_sizer = wx.BoxSizer(wx.HORIZONTAL)
        line_sizer.Add(wx.StaticText(self, label=u'总成交价:'), 0, wx.ALL | wx.ALIGN_RIGHT, 3)
        line_sizer.Add(wx.StaticText(self, label=u'--', name=u'summary_price'), 0, wx.ALL, 3)
        sizer.Add(line_sizer, 1, wx.ALL | wx.EXPAND, 3)

        # 总成交价（含佣金） 区
        line_sizer = wx.BoxSizer(wx.HORIZONTAL)
        line_sizer.Add(
            wx.StaticText(
                self,
                label=u'总成交价(含佣金):'),
            0,
            wx.ALL | wx.ALIGN_RIGHT,
            3)
        line_sizer.Add(
            wx.StaticText(
                self,
                label=u'--',
                name=u'summary_price_with_reward'),
            0,
            wx.ALL,
            3)
        sizer.Add(line_sizer, 1, wx.ALL | wx.EXPAND, 3)

        # 总成交率 区
        line_sizer = wx.BoxSizer(wx.HORIZONTAL)
        line_sizer.Add(
            wx.StaticText(
                self,
                label=u'总成交率:'),
            0,
            wx.ALL | wx.ALIGN_RIGHT,
            3)
        line_sizer.Add(
            wx.StaticText(
                self,
                label=u'--',
                name=u'summary_deal_percent'),
            0,
            wx.ALL,
            3)
        sizer.Add(line_sizer, 1, wx.ALL | wx.EXPAND, 3)

        return sizer

    def handle_dealed(self, evt):
        """
        把交易的参数存入redis里
        :return:
        """

        dlg = DealConfirmDlg(self)  # 交易确认对话框
        if dlg.ShowModal() != wx.ID_OK:
            live_redis.PriceInit(
                self.act['id'],
                self.sub_act['id'],
                self.antique['lot'],
                self.cur_price)
            return   # return退出一个函数

        reg_num = dlg.GetRegNum()
        if not reg_num:
            wx.MessageBox(u'未注册的竞投牌号!', u'错误信息', wx.OK)
            return
        # 更新数据库记录 bid_records 表
        db.Deal(self.sub_act['id'], self.antique['lot'], reg_num)
        # 写入 redis
        live_redis.Deal(
            self.act['id'],
            self.antique['lot'],
            self.antique['lot'],
            reg_num,
            self.cur_price)
        self.reset()
        self._next_antique()
        self._update_summary_info()

    # TODO 修改拍卖名称 短句的实现
    def change_antique_info(self, evt):
        dlg = ChangeAntInfoDlg(self)
        if dlg.ShowModal() != wx.ID_OK:
            return
        antique_info = dlg.GetAntiqueInfo()
        if antique_info:
            db.UpdateAntiqueInfo(
                self.sub_act['id'],
                self.antique['lot'],
                antique_info)
        # TODO 分词短行 ?
        name_text = self.FindWindowById(self.cur_antique_id)
        update_name = db.GetAntique(
            self.sub_act['id'],
            self.antique['lot'])['name']
        name_text.SetLabelText(update_name.decode('utf-8'))

    # TODO ?
    def cancel_change_antique(self, evt):
        name_input = self.FindWindowById(self.cur_antique_input_id)
        if name_input is None:
            return
        name_input.Destroy()
        change_btn = self.FindWindowById(self.change_ant_btn_id)
        change_btn.SetLabelText(u'修改拍品名称')
        self.Bind(wx.EVT_BUTTON, self.change_antique_info, change_btn)

    def save_antique(self, evt):
        name_input = self.FindWindowById(self.cur_antique_input_id)
        parent = self.GetSizer()
        update_name = name_input.GetValue()
        # TODO 这是修改拍卖的名字 ？
        db.UpdateAntiqueName(
            self.sub_act['id'],
            self.antique['lot'],
            update_name)

        name_input.Destroy()
        change_btn = self.FindWindowById(self.change_ant_btn_id)
        change_btn.SetLabelText(u'修改拍品名称')
        self.Bind(wx.EVT_BUTTON, self.change_antique_info, change_btn)
        name_txt = self.FindWindowById(self.cur_antique_id)
        name_txt.SetLabelText(update_name)

    def handle_missed(self, evt):
        """
        流拍业务逻辑
        通知redis 流拍产品
        :return:
        """
        db.Miss(self.sub_act['id'], self.antique['lot'])
        live_redis.Miss(self.act['id'], self.sub_act['id'], self.antique['lot'])
        self.reset()
        self._next_antique()
        self._update_summary_info()

    def handle_canceled(self):
        # TODO: db error handling: psycopg2.InternalError, psycopg2.ProgrammingError
        # TODO: handle rebid nicely on verification app
        if wx.MessageBox(u'确认要撤怕？', u'提示信息', wx.OK | wx.CANCEL) != wx.OK:
            return
        db.Cancel(self.sub_act['id'], self.antique['lot'])
        live_redis.Cancel(self.act['id'], self.sub_act['id'], self.antique['lot'])
        self.reset()
        self._next_antique()
        self._update_summary_info()

    def handle_pre_antique(self, evt):
        self.reset()
        self._pre_antique()
        self._update_summary_info()

    def handle_price_up(self, evt):
        """
        加价
        :param:evt 事件参数，必须有
        :return:
        """
        if self.delta_price.__class__ == Rate258Price:
            self.cur_price += self.delta_price.up(self.cur_price)
        else:
            self.cur_price += self.delta_price
        self._update_cur_price()

    def handle_price_down(self,evt):
        """
        减价
        :return:
        """
        if self.delta_price.__class__ == Rate258Price:
            self.cur_price += self.delta_price.down(self.cur_price)
        else:
            self.cur_price -= self.delta_price
        self.cur_price = max(0, self.cur_price)
        self._update_cur_price()

    def handle_next_antique(self):
        self.reset()
        self._next_antique()
        self._update_summary_info()

    def _update_cur_price(self, is_firsttime=False):
        cur_price_txt = self.FindWindowById(self.cur_price_id)

        cur_price_txt.SetLabel(money_amount_to_s(self.cur_price))
        self.GetTopLevelParent().slide_frame.OnPriceChanged(self.cur_price)
        msg = db.PriceUpdate(
            self.sub_act['id'],
            self.antique['lot'],
            self.cur_price)
        if msg == 'err':
            wx.MessageBox(u'数据录入有误，请检查后重新输入', u'提示信息', wx.OK)
            return

        if is_firsttime:
            live_redis.PriceInit(self.act['id'], self.sub_act['id'],
                                 self.antique['lot'], self.cur_price)
        else:
            live_redis.PriceUpdate(self.act['id'], self.sub_act['id'],
                                   self.antique['lot'], self.cur_price)

    def handle_delta_price(self, evt):
        """
        价格控制区 --- 选择不同价格标签
        :param evt:
        :return:
        """
        # TODO ?
        # Returns the object (usually a window) associated with the event, if any.
        btn = evt.GetEventObject()
        if btn.GetValue():
            for b in self.price_btns:
                if b == btn:
                    continue
                # TODO ?
                b.SetValue(False)
            label = btn.GetLabel()
            if label == u'2位258':
                self.delta_price = self.rate2
            elif label == u'100万':
                self.delta_price = 1000000
            elif label == u'50万':
                self.delta_price = 500000
            elif label == u'10万':
                self.delta_price = 100000
            elif label == u'5万':
                self.delta_price = 50000
            elif label == u'1万':
                self.delta_price = 10000
            else:
                self.delta_price = int(label.replace(',', ''))
        else:
            self.delta_price = 0

    def handle_init_price(self, evt):
        """叫价输入"""
        self.cur_price = int(evt.GetEventObject().GetValue())
        print self.cur_price
        # 更新当前的最新加价
        self._update_cur_price(is_firsttime=True)

        self.FindWindowById(
            self.initial_price_id).SetLabel(money_amount_to_s(self.cur_price))

    def handle_lot_location(self, evt):
        """
        拍品定位事件
        :param evt:
        :return:
        """
        val = self.FindWindowById(self.lot_locator_id).GetValue()
        if not val:
            return

        antique = db.GetAntique(self.sub_act['id'], val)
        status = db.GetAntiqueStatus(self.sub_act['id'], val)
        if status in ('deal', 'fail', 'cancel'):
            if wx.MessageBox(
                    u'%s号拍品已经拍过，是否要重拍?' %
                    val,
                    u'提示信息',
                    wx.YES_NO) != wx.YES:
                return
            db.ReBid(self.sub_act['id'], val)
            live_redis.ReBid(self.act['id'], self.sub_act['id'], self.antique['lot'])

        self._notify_antique_changed(antique)

    def handle_sub_act_config(self, evt):
        self._config_sub_act()

    def _update_app_title(self):
        print (self.act['name'], self.sub_act['name'])
        title = u'诚轩拍卖现场 - %s > %s' % (self.act['name'].decode('utf-8'), self.sub_act['name'].decode('utf-8'))
        print title
        self.GetTopLevelParent().SetTitle(title)

    def _notify_antique_changed(self, new_antique):
        if not new_antique:
            wx.MessageBox(u'已是最后一件拍品，本次拍品即将结束', u'提示信息', wx.OK)
            return

        self.antique = new_antique
        db.NewBid(self.act['id'], self.sub_act['id'], self.antique['lot'])
        live_redis.NewBid(
            self.act['id'],
            self.sub_act['id'],
            self.antique['lot'])

        next_antique = db.GetNextAntique(
            self.sub_act['id'], self.antique['lot'])
        print '---3',self.antique.get('name'), next_antique
        self.GetTopLevelParent().slide_frame.OnAntiqueChanged(self.antique, next_antique)

        self._update_antique_info()

    def _notify_sub_act_changed(self, new_sub_act):
        self.sub_act = new_sub_act
        self._update_app_title()
        self._update_summary_info()
        self.GetTopLevelParent().slide_frame.OnSubActChanged(self.act, self.sub_act)
        self.GetTopLevelParent().slide_frame.OnExchangeRateChanged(self.exchange_rate)

        self._next_antique()

    def _config_sub_act(self):
        """
        专场选择及汇率设置对话框
        :return:
        """
        dlg = SubActConfigDlg(self)
        dlg.DoInit(self.act, self.sub_act)
        dlg.Center()
        if dlg.ShowModal() == wx.ID_OK:
            cur_sub_act = dlg.GetSubAct()
            self.reward_percent = dlg.GetRewardPercent()
            cur_sub_act['reward_percent'] = self.reward_percent
            # TODO deepcopy ?
            self.exchange_rate = copy.deepcopy(dlg.exchange_rate)
            self._notify_sub_act_changed(cur_sub_act)
            db.UpdateSubActRewardPercent(cur_sub_act['id'], self.reward_percent)

        else:
            self.GetTopLevelParent().Close()

    def _next_antique(self):
        # TODO and or ?
        lot = self.antique and self.antique['lot'] or 0
        new_antique = db.GetNextAntique(self.sub_act['id'], lot)
        self._notify_antique_changed(new_antique)

    def _pre_antique(self):
        lot = self.antique and self.antique['lot'] or 0
        new_antique = db.GetPrevAntique(self.sub_act['id'], lot)
        self._notify_antique_changed(new_antique)

    def _update_summary_info(self):
        sub_act_id = self.sub_act['id']
        print sub_act_id
        label = self.FindWindowByName(u'summary_total_count')
        print label
        count = db.GetAntiqueTotalCount(sub_act_id)
        label.SetLabel(str(count))

        label = self.FindWindowByName(u'summary_dealed_count')
        deal_count = db.GetDealedCount(sub_act_id)
        label.SetLabel(str(deal_count))

        label = self.FindWindowByName(u'summary_price')
        sum_price = db.GetPriceSum(sub_act_id)
        label.SetLabel(money_amount_to_s(sum_price))

        label = self.FindWindowByName(u'summary_price_with_reward')
        sum_price_with_reward = sum_price + sum_price * self.reward_percent / 100.0
        label.SetLabel(money_amount_to_s(sum_price_with_reward))

        label = self.FindWindowByName(u'summary_deal_percent')

        miss_count = db.GetMissedCount(sub_act_id)
        if deal_count + miss_count > 0:
            deal_percent = deal_count * 100.0 / (deal_count + miss_count)
            label.SetLabel("%.2f%%" % deal_percent)

        cancel_count = db.GetCancelledCount(sub_act_id)
        pending_count = count - deal_count - miss_count - cancel_count
        self.GetTopLevelParent().slide_frame.OnSummaryChanged(count, pending_count)

    def get_antique_label(self, antique):
        # TODO 被谁引用？
        return u' '.join(v for v in (antique['author'], antique['age'], antique['name']) if v)

    def _update_antique_info(self):
        label = self.FindWindowByName(u'antique_lot')
        lot = self.antique['lot']
        label.SetLabel(str(lot))

        label = self.FindWindowByName(u'antique_name')
        label.SetLabel(self.antique['name'].decode('utf-8'))

        self._load_antique_image(lot)

    def _load_antique_image(self, lot):
        antique_bmp = lot_image(lot)

        parent = self.bmp_static.GetParent()
        # TODO 拍品图片转化？
        if config.convert_img_on_fly:
            antique_bmp = img_scale(antique_bmp, parent.GetSize())

        self.bmp_static.SetSize(antique_bmp.GetSize())
        self.bmp_static.SetBitmap(antique_bmp)
        self.bmp_static.CenterOnParent()

    def update_font(self):
        win_list = self.GetChildren()
        font = wx.SystemSettings.GetFont(wx.SYS_SYSTEM_FONT)
        for win in win_list:
            if type(win).__name__ == u'ToggleButton':
                font.SetPointSize(30)
                win.SetFont(font)
            else:
                font.SetPointSize(18)
                win.SetFont(font)


def run():
    app = AuctionLiveApp(False)
    app.MainLoop()


if __name__ == '__main__':
    run()
