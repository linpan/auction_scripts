# encoding: UTF-8

import time

import wx

import sys
import os
sys.path.insert(0, os.path.abspath(
  os.path.join(os.path.dirname(__file__), '..')))

from auction_live.common import convert_img

if __name__ == "__main__":
  app = wx.App(False)
  print u'开始转化图片'
  start_ts = time.time()
  convert_img()
  end_ts = time.time()
  print u'完成图片转化，共用%s秒' % int(end_ts - start_ts)
