# encoding: UTF-8

import wx
import wx.lib.intctrl

class ChangeAntInfoDlg(wx.Dialog):
  def __init__(self, parent):

    wx.Dialog.__init__(self, parent, title=u'修改拍品信息')
    sizer = wx.GridBagSizer(5, 5)

    name_sizer = wx.BoxSizer(wx.HORIZONTAL)
    name_sizer.Add(wx.StaticText(self, label=u'名称1:'), 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 3)
    self.cur_antique_name_id= wx.NewId()
    name_input = wx.TextCtrl(self, self.cur_antique_name_id,
                             size=(200, 35),
                             name='name',
                             value=parent.antique['name'].decode('utf-8'),
                             style=wx.TE_MULTILINE | wx.EXPAND)
    name_sizer.Add(name_input, 1, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 3)
    sizer.Add(name_sizer, (0, 0), (1, 2), wx.EXPAND | wx.ALL, 1)
    print parent.antique
    if parent.antique['name2']:
        name2_sizer = wx.BoxSizer(wx.HORIZONTAL)
        name2_sizer.Add(wx.StaticText(self, label=u'名称2:'), 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 3)
        self.cur_antique_name2_id = wx.NewId()
        name_input = wx.TextCtrl(self, self.cur_antique_name2_id,
                                 size=(200, 35),
                                 name='name2',
                                 value=parent.antique['name2'],
                                 style=wx.TE_MULTILINE | wx.EXPAND)
        name2_sizer.Add(name_input, 1, wx.ALIGN_CENTER_VERTICAL|wx.ALL, 3)
        sizer.Add(name2_sizer, (1, 0), (1, 2), wx.EXPAND | wx.ALL, 1)

    if parent.antique['author']:
        author_sizer = wx.BoxSizer(wx.HORIZONTAL)
        author_sizer.Add(wx.StaticText(self, label=u'作者1:'), 0, wx.ALL | wx.RIGHT, 3)
        self.cur_antique_author_id = wx.NewId()
        name_input = wx.TextCtrl(self, self.cur_antique_author_id,
                                 size=(200, 35),
                                 name='author',
                                 value=parent.antique['author'].decode('utf-8'),
                                 style=wx.TE_MULTILINE | wx.EXPAND)
        author_sizer.Add(name_input, 0, wx.ALIGN_CENTER_VERTICAL|wx.ALL, 1)
        sizer.Add(author_sizer, (2, 0), (1, 2), wx.EXPAND | wx.ALL, 1)

    if parent.antique['author2']:
        author2_sizer = wx.BoxSizer(wx.HORIZONTAL)
        author2_sizer.Add(wx.StaticText(self, label=u'作者2:'), 0, wx.ALL | wx.RIGHT, 3)
        self.cur_antique_author2_id = wx.NewId()
        name_input = wx.TextCtrl(self, self.cur_antique_author2_id,
                                 size=(200, 35),
                                 name='author2',
                                 value=parent.antique['author2'],
                                 style=wx.TE_MULTILINE | wx.EXPAND)
        author2_sizer.Add(name_input, 0, wx.ALIGN_CENTER_VERTICAL | wx.ALL, 1)
        sizer.Add(author2_sizer, (3, 0), (1, 2), wx.EXPAND | wx.ALL, 1)

    if parent.antique['age']:
        author2_sizer = wx.BoxSizer(wx.HORIZONTAL)
        author2_sizer.Add(wx.StaticText(self, label=u'年代:'), 0, wx.ALL | wx.RIGHT, 3)
        self.cur_antique_age_id = wx.NewId()
        name_input = wx.TextCtrl(self, self.cur_antique_age_id,
                                 size=(200, 35),
                                 name='age',
                                 value=parent.antique['age'].decode('utf-8'),
                                 style=wx.TE_MULTILINE | wx.EXPAND)
        author2_sizer.Add(name_input, 0, wx.ALIGN_CENTER_VERTICAL | wx.ALL, 2)
        sizer.Add(author2_sizer, (4, 0), (1, 3), wx.EXPAND | wx.ALL, 1)

    sizer.Add(self.CreateStdDialogButtonSizer(wx.OK|wx.CANCEL),
              (5, 0), (1, 3), wx.ALL|wx.ALIGN_CENTER_HORIZONTAL, 3)
    self.SetSizerAndFit(sizer)

    self.Center()

  def GetAntiqueInfo(self):
      antique_info_list = ['name', 'name2', 'author', 'author2', 'age']
      ant_list = []
      for info in antique_info_list:
          if self.FindWindowByName(info):
            value = self.FindWindowByName(info).GetValue()
            ant_list.append("%s='%s'" % (info, value))
      ant_expression = ', '.join(ant_list)
      return ant_expression
