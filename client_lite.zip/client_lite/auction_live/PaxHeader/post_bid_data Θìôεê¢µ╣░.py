68 path=./auction/client/auction_live/post_bid_data å¯æ¬.py
20 ctime=1511494068
20 atime=1512185501
38 LIBARCHIVE.creationtime=1511404210
24 SCHILY.dev=234881026
22 SCHILY.ino=5935454
18 SCHILY.nlink=1
