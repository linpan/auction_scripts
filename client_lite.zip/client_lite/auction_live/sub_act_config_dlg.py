# encoding: UTF-8

import wx
import wx.lib.intctrl

from lib.validator import *
import db

class SubActConfigDlg(wx.Dialog):
  def __init__(self, parent):
    wx.Dialog.__init__(self, parent)
    self.sub_acts = None
    self.selector = None
    self.exchange_rate = {'usd': 1,
                          'eur': 1,
                          'hkd': 1}

  def DoInit(self, act, cur_sub_act=None):
    cur_sub_act = cur_sub_act or {}
    main_sizer = wx.BoxSizer(wx.VERTICAL)
    sizer = wx.FlexGridSizer(cols=2, hgap=4, vgap=4)

    sizer.Add(wx.StaticText(self, label=u'专场选择:'), 0,
              wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5)
    self.sub_acts = db.GetSubactivities(act['id'])
    choices = [sub['name'].decode('utf-8') for sub in self.sub_acts]
    self.selector = wx.Choice(self, choices=choices)
    sizer.Add(self.selector, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5)

    if cur_sub_act:
      self.selector.SetSelection(
        self.selector.FindString(cur_sub_act['name']))

    sizer.Add(wx.StaticText(self, label=u'专场佣金比率:'), 0,
              wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5)
    line_sizer = wx.BoxSizer(wx.HORIZONTAL)
    txt = wx.lib.intctrl.IntCtrl(self, name=u'reward_percent',
                                 value=cur_sub_act.get('reward_percent', 15))
    line_sizer.Add(txt, 1, wx.ALL, 5)
    line_sizer.Add(wx.StaticText(self, label=u'%'), 0,
                   wx.ALL|wx.ALIGN_CENTER_VERTICAL, 2)
    sizer.Add(line_sizer, 0, wx.ALL|wx.EXPAND, 5)
    main_sizer.Add(sizer, 0, wx.EXPAND|wx.ALL, 5)

    box = wx.StaticBox(self, label=u'汇率设置')
    boxsizer = wx.StaticBoxSizer(box, wx.VERTICAL)

    inner_sizer = wx.FlexGridSizer(cols=3, hgap=4, vgap=4)
    v_cls = GetValidator(NumberValidatorMixin)
    inner_sizer.Add(wx.StaticText(self, label=u'1 HKD ='), wx.ALIGN_CENTER_VERTICAL)
    validator = v_cls(self.exchange_rate, 'hkd', allow_empty=False, min_val=0)
    inner_sizer.Add(wx.TextCtrl(self, value='0.8', validator=validator))
    inner_sizer.Add(wx.StaticText(self, label=u'RMB'), wx.ALIGN_CENTER_VERTICAL)

    inner_sizer.Add(wx.StaticText(self, label=u'1 USD ='), wx.ALIGN_CENTER_VERTICAL)
    validator = v_cls(self.exchange_rate, 'usd', allow_empty=False, min_val=0)
    inner_sizer.Add(wx.TextCtrl(self, value='6.8', validator=validator))
    inner_sizer.Add(wx.StaticText(self, label=u'RMB'), wx.ALIGN_CENTER_VERTICAL)

    inner_sizer.Add(wx.StaticText(self, label=u'1 EUR ='), wx.ALIGN_CENTER_VERTICAL)
    validator = v_cls(self.exchange_rate, 'eur', allow_empty=False, min_val=0)
    inner_sizer.Add(wx.TextCtrl(self, value='10.8', validator=validator))
    inner_sizer.Add(wx.StaticText(self, label=u'RMB'), wx.ALIGN_CENTER_VERTICAL)
    inner_sizer.AddGrowableCol(1, 1)

    boxsizer.Add(inner_sizer, wx.EXPAND|wx.ALL, 5)
    main_sizer.Add(boxsizer, 1, wx.EXPAND|wx.ALL, 5)

    line_sizer = wx.BoxSizer(wx.VERTICAL)
    line_sizer.Add(self.CreateStdDialogButtonSizer(wx.OK|wx.CANCEL),
              0, wx.ALL|wx.ALIGN_CENTER_HORIZONTAL, 5)
    main_sizer.Add(line_sizer, 0, wx.EXPAND|wx.ALL, 5)

    self.SetSizerAndFit(main_sizer)

  def GetSubAct(self):
    return self.sub_acts[self.selector.GetSelection()]

  def GetRewardPercent(self):
    txt = self.FindWindowByName(u'reward_percent')
    return txt.GetValue()

