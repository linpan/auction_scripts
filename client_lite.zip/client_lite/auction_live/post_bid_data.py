# encoding: UTF-8

import socket
import time

from urlparse import urljoin
import urllib
import urllib2

import sys
import os

sys.path.insert(0, os.path.abspath(
    os.path.join(os.path.dirname(__file__), '..')))

import db

from config import get_logger
from config import verification_server_info
from config import sub_act_id_mapping
from config import web_live_server_info
from config import web_live_beta_server_info
from config import send_bid

import live_redis_client


class BasePoster:
    def __init__(self, host, user=None, passwd=None):
        self.host = host
        self.user = user
        self.passwd = passwd

        self.act = db.GetActiveActivity()
        self.act_id = self.act['id']

        # def _do_post(self, method, full_url, data):
        # conn = Http()
        ## FIXME: workaround nginx content-length issue
        # headers = {'Content-Length': '0'}
        # resp, content = conn.request(full_url, method, urllib.urlencode(data),
        # headers=headers)
        # return resp.status, resp.values(), content

    def _do_post(self, method, full_url, data):
        # self.logger.info("i am here!", full_url)
        if data:
            data = urllib.urlencode(data)
            r = urllib2.urlopen(full_url, data=data)
        else:
            self.logger.info(full_url)
            self.logger.info("start send in get")
            r = urllib2.urlopen(full_url, timeout=10)
            self.logger.info("sent data resp get: %s" % r.read())
        return r.getcode(), r.headers.values(), r.read()

    def post_data(self, full_url, data):
        # self.logger.info("Start to post to %s data(%s) ..."
        #                 % (full_url, data))
        print("Start to post to data ...")

        method = self.get_send_method(data)
        self.logger.info("Method: %s" % method)
        status, headers, content = self._do_post(method, full_url, data)
        # self.logger.info("status after sent data")
        print("status after sent data ...")
        if status == 200:
            # self.logger.info("Succeed!")
            print("Succeed!")
            return True
        else:
            # self.logger.info("Failed! (status: %s, headers: %s, content: %s)" %
            #                 (status, headers, content))
            print("Failed! ", status, headers, content)
            return False

    def send_data(self, bid):
        print("host ", self.host)
        print("label ", self.label)


        full_url = self.build_url(bid, self.host)

        beta_full_url = self.build_url(bid, web_live_beta_server_info['host'])
        print 'full_url %s'% beta_full_url
        data = self.build_data(bid)
        is_succeed = False
        try:
            if self.post_data(full_url, data):
                self.mark_data(bid)
                is_succeed = True
        except socket.error as exp:
            self.logger.error('Got socket.error exception (%s), maybe server crashed?' % exp)
        except socket.timeout as exp:
            self.logger.error('Got server timeout exception, maybe network broken?')
            self.logger.info('got server timeout exception!!~~!!')
        except socket.herror as exp:
            self.logger.error('Got socket.herror exception (%s), maybe DNS or network setting issue?' % exp)
        except socket.gaierror as exp:
            self.logger.error('Got socket.gaierror exception (%s), maybe DNS or network setting issue?' % exp)
        except:
            self.logger.error("Got unexpected error: %s" % repr(sys.exc_info()[0]))
        if send_bid == 'true' and self.label == 'live':
            print 'end....'
            self.logger.info("------start----post---data---to---bid---server---")
            print("start post data to bid server...")
            try:
                if self.post_data(beta_full_url, data):
                    is_succeed = True
            except socket.error as exp:
                self.logger.error('Got socket.error exception (%s), maybe server crashed?' % exp)
            except socket.timeout as exp:
                self.logger.error('Got server timeout exception, maybe network broken?')
                self.logger.info('got server timeout exception!!~~!!')
            except socket.herror as exp:
                self.logger.error('Got socket.herror exception (%s), maybe DNS or network setting issue?' % exp)
            except socket.gaierror as exp:
                self.logger.error('Got socket.gaierror exception (%s), maybe DNS or network setting issue?' % exp)
            except:
                self.logger.error("Got unexpected error: %s" % repr(sys.exc_info()[0]))

        if not is_succeed:
            self.recycle_data(bid)

    def mark_data(self, bid):
        pass

    def recycle_data(self, bid):
        pass

    def run(self, interval=5):
        # self.logger.info("Data poster deamon service started!")
        self.logger.info('running...')

        while 1:
            datas = self.fetch_data()

            if datas:
                self.logger.info("Fetched #%s data from db" % len(datas))
                print("Fetched data from db", len(datas))
                for data in datas:
                    self.send_data(data)
            else:
                self.logger.info("No data available, sleep a while ...")
                print("No data available, sleep a while ...")
            if interval is not None:
                print("sleeping ...")
                time.sleep(interval)


class VerificationDataPoster(BasePoster):
    def __init__(self, host, user=None, passwd=None):
        BasePoster.__init__(self, host, user, passwd)
        self.logger = get_logger(self.__class__.__name__)
        self.label = 'verify'

    def get_send_method(self, data):
        if data.get('rebid', False):
            return 'PUT'
        else:
            return 'POST'

    def fetch_data(self):
        self.logger.info("Fetch bid data from db ...")
        return db.GetBidDataForPost(self.act_id)

    def build_url(self, bid, host):
        sub_act_id = bid['sub_activity_id']
        url = '/activity/%s/sub_activity/%s/transactions' % (self.act_id, sub_act_id)
        return urljoin(host, url)

    def build_data(self, bid):
        data = {'lot': bid['lot']}
        if bid.get('rebid', None):
            data['rebid'] = bid['rebid']
        if bid['status'] == 'deal':
            data['deal_state'] = 'dealed'
            data['reg_num'] = bid['reg_num']
            data['price'] = bid['price']
        elif bid['status'] == 'fail':
            data['deal_state'] = 'missed'
        elif bid['status'] == 'cancel':
            data['state'] = 'canceled'
        return data

    def mark_data(self, bid):
        db.MarkBidDataSent(bid['id'])


class LiveDataPoster(BasePoster):
    def __init__(self, host, user=None, passwd=None):
        BasePoster.__init__(self, host, user, passwd)
        self.logger = get_logger(self.__class__.__name__)
        self.label = 'live'

    def get_send_method(self, data):
        return "GET"

    def fetch_data(self):
        # self.logger.info("Fetch live bid data from redis ...")
        print("Fetch live bid data from redis ...")
        return live_redis_client.GetRecordFromRedis(self.act_id)

    def build_url(self, bid, host=None):
        # print 'hhih',exit()
        sub_act_id = bid['sub_act_id']
        lot = bid['lot']
        event_type = bid['event_type']
        price = bid.get('price', '')
        # print sub_act_id,lot,event_type,price,exit()
        print sub_act_id
        sub_act_id_ = sub_act_id_mapping.get(sub_act_id, None)
        # print 'have a value', sub_act_id_, exit()
        if sub_act_id_ is None:
            # print exit()
            return None
        url = "/live/%s/control/%s/?" % (sub_act_id_, lot)
        # print  url, exit()

        url_map = {'NewBid': 'lot=%s' % lot,
                   'PriceInit': 'price=%s&status=ongoing' % price,
                   'Deal': 'price=%s&status=deal&reg_num=%s' % (
                       price, bid.get('reg_num', '')),
                   'Miss': 'price=%s&status=fail' % price,
                   'Cancel': 'price=%s&status=cancel' % price,
                   'PriceUpdate': 'price=%s' % price}

        url += url_map.get(event_type, '')

        return urljoin(host, url)

    def build_data(self, bid):
        return None

    def mark_data(self, bid):
        live_redis_client.MarkRecordSuccess(self.act_id, bid)

    def recycle_data(self, bid):
        live_redis_client.AddRecordBack(self.act_id, bid)


if __name__ == "__main__":
    name = len(sys.argv) > 1 and sys.argv[1] or 'verify'
    if name == 'verify':
        print("verify")
        p = VerificationDataPoster(verification_server_info['host'],
                                   verification_server_info.get('user', None),
                                   verification_server_info.get('passwd', None))
        interval = 5
    else:
        # production
        p = LiveDataPoster(web_live_server_info['host'],
                           web_live_server_info.get('user', None),
                           web_live_server_info.get('passwd', None))

        # test
        # p = LiveDataPoster(web_live_beta_server_info['host'],
        #                    web_live_beta_server_info.get('user', None),
        #                    web_live_beta_server_info.get('passwd', None))
        interval = None
    try:
        p.run(interval)
    except:
        print "Got unexpected error:", sys.exc_info()[0]

