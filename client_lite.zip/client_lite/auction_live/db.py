# encoding: UTF-8

import datetime

import contextlib
import psycopg2

from config import db

_conn = None
def conn():
  global _conn
  if _conn is None:
    _conn = psycopg2.connect(
      "dbname=%(name)s user=%(user)s password=%(password)s" % db)
  return _conn


def GetActiveActivity():
  with contextlib.closing(conn().cursor()) as cur:
    cur.execute("SELECT id, name FROM activities ORDER BY id DESC limit 1")
    if not cur.rowcount: return
    rs = cur.fetchone()
    return {'id': rs[0], 'name': rs[1]}

def GetSubactivities(act_id):
  with contextlib.closing(conn().cursor()) as cur:
    fields = ('id', 'name')
    sql = "SELECT %s FROM sub_activities WHERE activity_id=%%s ORDER BY id" \
        % ','.join(fields)
    cur.execute(sql, (act_id,))
    return [dict(zip(fields, row)) for row in cur]

def GetNextAntique(sub_act_id, cur_antique_lot=0):
  cur_antique_lot = cur_antique_lot or 0
  with contextlib.closing(conn().cursor()) as cur:
    fields = ['id', 'lot', 'name', 'age', 'size', 'author', 'texture',
              'name2', 'author2']

    #'ready', 'ongoing', 'deal', 'fail', 'cancel'
    cur.execute('''SELECT %s FROM antiques as a
                WHERE a.sub_activity_id=%%s AND a.lot > %%s
                AND a.ready_for_auction = true
                AND NOT EXISTS (SELECT 1 FROM bid_records AS b
                WHERE b.status IN ('deal', 'fail', 'cancel')
                AND b.lot=a.lot AND b.sub_activity_id=a.sub_activity_id)
                ORDER BY a.lot asc LIMIT 1''' % ','.join(fields),
               (sub_act_id, cur_antique_lot))

    if not cur.rowcount:
      return
    return dict(zip(fields, cur.fetchone()))

def GetPrevAntique(sub_act_id, cur_antique_lot=0):
  cur_antique_lot = cur_antique_lot or 0
  with contextlib.closing(conn().cursor()) as cur:
    fields = ['id', 'lot', 'name', 'age', 'size', 'author', 'texture',
              'name2', 'author2']

    #'ready', 'ongoing', 'deal', 'fail', 'cancel'
    cur.execute('''SELECT %s FROM antiques as a
                WHERE a.sub_activity_id=%%s AND a.lot < %%s
                AND a.ready_for_auction = true
                AND NOT EXISTS (SELECT 1 FROM bid_records AS b
                WHERE b.status IN ('deal', 'fail', 'cancel')
                AND b.lot=a.lot AND b.sub_activity_id=a.sub_activity_id)
                ORDER BY a.lot desc LIMIT 1''' % ','.join(fields),
               (sub_act_id, cur_antique_lot))

    if not cur.rowcount:
      return
    return dict(zip(fields, cur.fetchone()))

def GetAntique(sub_act_id, lot):
  with contextlib.closing(conn().cursor()) as cur:
    fields = ['id', 'lot', 'name', 'age', 'size', 'author', 'texture',
              'name2', 'author2']
    cur.execute('''SELECT %s FROM antiques
                WHERE sub_activity_id=%%s AND lot=%%s'''
                % ','.join(fields),
               (sub_act_id, lot))

    if not cur.rowcount:
      return
    return dict(zip(fields, cur.fetchone()))

def UpdateAntiqueName(sub_act_id, lot, name_txt):
  c = conn()
  with contextlib.closing(conn().cursor()) as cur:
    sql = '''update antiques set name=%s where sub_activity_id=%s and lot=%s'''
    cur.execute(sql, (name_txt, sub_act_id, lot))
    c.commit()

def UpdateAntiqueInfo(sub_act_id, lot, kws):
  c = conn()
  with contextlib.closing(conn().cursor()) as cur:
    sql = '''update antiques set %s where sub_activity_id=%s and lot=%s''' % (kws, sub_act_id, lot)
    cur.execute(sql)
    c.commit()

def GetAntiqueStatus(sub_act_id, lot):
  with contextlib.closing(conn().cursor()) as cur:
    cur.execute('''SELECT status FROM bid_records WHERE sub_activity_id=%s
                AND lot=%s''', (sub_act_id, lot))
    if not cur.rowcount:
      return
    return cur.fetchone()[0]

def GetAntiqueTotalCount(sub_act_id):
  with contextlib.closing(conn().cursor()) as cur:
    #TODO: include canceled antiques?
    cur.execute('SELECT count(1) FROM antiques WHERE sub_activity_id=%s and ready_for_auction = true ',
                (sub_act_id,))
    return cur.fetchone()[0] or 0

def GetDealedCount(sub_act_id):
  with contextlib.closing(conn().cursor()) as cur:
    cur.execute('''SELECT count(1) FROM bid_records WHERE sub_activity_id=%s
                and status='deal' ''',
                (sub_act_id,))
    return cur.fetchone()[0] or 0

def GetMissedCount(sub_act_id):
  with contextlib.closing(conn().cursor()) as cur:
    cur.execute('''SELECT count(1) FROM bid_records WHERE sub_activity_id=%s
                and status='fail' ''',
                (sub_act_id,))
    return cur.fetchone()[0] or 0

def GetCancelledCount(sub_act_id):
  with contextlib.closing(conn().cursor()) as cur:
    cur.execute('''SELECT count(1) FROM bid_records WHERE sub_activity_id=%s
                and status='cancel' ''',
                (sub_act_id,))
    return cur.fetchone()[0] or 0

def GetPriceSum(sub_act_id):
  with contextlib.closing(conn().cursor()) as cur:
    cur.execute('''SELECT sum(price) FROM bid_records WHERE sub_activity_id=%s
                AND status='deal' ''', (sub_act_id,))
    return cur.fetchone()[0] or 0

def NewBid(act_id, sub_act_id, lot):
  c = conn()
  with contextlib.closing(c.cursor()) as cur:
    sql = "select count(1) from bid_records where sub_activity_id=%s and lot=%s"
    cur.execute(sql, (sub_act_id, lot))
    if cur.fetchone()[0] != 0:
      return

    sql = '''INSERT INTO bid_records(activity_id, sub_activity_id, lot, status)
             VALUES (%s, %s, %s, %s)'''
    cur.execute(sql, (act_id, sub_act_id, lot, 'ready'))
    c.commit()

def ReBid(sub_act_id, lot):
    #print("start to rebid...")
  c = conn()
  with contextlib.closing(c.cursor()) as cur:
    sql = '''UPDATE bid_records SET status='ready', price=NULL,
    reg_num=NULL, rebid=true,
    live_data_sent_ts=NULL, verification_data_sent_ts=NULL
    WHERE sub_activity_id=%s AND lot=%s'''
    cur.execute(sql, (sub_act_id, lot))
    c.commit()

def Deal(sub_act_id, lot, reg_num):
    #print("start to deal...")
  c = conn()
  with contextlib.closing(c.cursor()) as cur:
    sql = '''UPDATE bid_records SET status='deal', reg_num='%s' WHERE
             sub_activity_id=%s AND lot=%s'''
    cur.execute(sql, (reg_num, sub_act_id, lot))
    c.commit()

def PriceUpdate(sub_act_id, lot, price):
  c = conn()
  with contextlib.closing(c.cursor()) as cur:
    sql = '''UPDATE bid_records SET status='ongoing', price='%s'
    WHERE sub_activity_id=%s AND lot=%s'''
    try:
      cur.execute(sql, (price, sub_act_id, lot))
      c.commit()
      return 'ok'
    except psycopg2.DataError, e:
      c.rollback()
      return 'err'

def Miss(sub_act_id, lot):
  c = conn()
  with contextlib.closing(c.cursor()) as cur:
    sql = '''UPDATE bid_records SET status='fail' WHERE
             sub_activity_id=%s AND lot=%s'''
    cur.execute(sql, (sub_act_id, lot))
    c.commit()

def Cancel(sub_act_id, lot):
  c = conn()
  with contextlib.closing(c.cursor()) as cur:
    sql = '''UPDATE bid_records SET status='cancel' WHERE
             sub_activity_id=%s AND lot=%s'''
    cur.execute(sql, (sub_act_id, lot))
    c.commit()

def UpdateSubActRewardPercent(sub_act_id, percent):
  c = conn()
  with contextlib.closing(c.cursor()) as cur:
    sql = '''UPDATE sub_activities SET reward_percent=%s
    WHERE id=%s'''
    cur.execute(sql, (percent, sub_act_id))
    c.commit()

def GetBidDataForPost(act_id):
  c = conn()
  with contextlib.closing(c.cursor()) as cur:
    fields = ('id', 'sub_activity_id', 'lot', 'status', 'price', 'reg_num',
              'rebid')
    sql = '''
    SELECT %s FROM bid_records WHERE activity_id=%%s
    AND verification_data_sent_ts IS NULL
    AND status IN ('deal', 'fail', 'cancel')
    LIMIT 10 ''' % ','.join(fields)
    cur.execute(sql, (act_id,))
    if not cur.rowcount:
      return
    return [dict(zip(fields, row)) for row in cur]

def MarkBidDataSent(data_id):
  c = conn()
  with contextlib.closing(c.cursor()) as cur:
    sql = 'UPDATE bid_records SET verification_data_sent_ts=%s WHERE id=%s'
    cur.execute(sql, (datetime.datetime.now(), data_id))
    c.commit()
