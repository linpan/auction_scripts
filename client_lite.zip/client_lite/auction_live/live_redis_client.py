import redis
import json

import config

_redis = None


def get_redis():
    global _redis
    if _redis is None:
        _redis = redis.StrictRedis(config.live_redis_host,
                                   config.live_redis_port, db=0)
    return _redis


def NewBid(act_id, sub_act_id, lot):
    r = get_redis()
    key = 'auction_live-%s' % act_id
    event = {'event_type': 'NewBid', 'lot': lot, 'sub_act_id': sub_act_id}
    r.rpush(key, json.dumps(event))


def ReBid(act_id, sub_act_id, lot):
    r = get_redis()
    key = 'auction_live-%s' % act_id
    event = {'event_type': 'ReBid', 'lot': lot, 'sub_act_id': sub_act_id}
    r.rpush(key, json.dumps(event))


def Deal(act_id, sub_act_id, lot, reg_num, price):
    r = get_redis()
    key = 'auction_live-%s' % act_id
    event = {'event_type': 'Deal', 'lot': lot,
             'reg_num': reg_num, 'price': price, 'sub_act_id': sub_act_id}
    r.rpush(key, json.dumps(event))


def PriceInit(act_id, sub_act_id, lot, price):
    r = get_redis()
    key = 'auction_live-%s' % act_id
    event = {'event_type': 'PriceInit', 'lot': lot, 'price': price,
             'sub_act_id': sub_act_id}
    r.rpush(key, json.dumps(event))


def PriceUpdate(act_id, sub_act_id, lot, price):
    r = get_redis()
    key = 'auction_live-%s' % act_id
    event = {'event_type': 'PriceUpdate', 'lot': lot, 'price': price,
             'sub_act_id': sub_act_id}
    r.rpush(key, json.dumps(event))


def Miss(act_id, sub_act_id, lot):
    r = get_redis()
    key = 'auction_live-%s' % act_id
    event = {'event_type': 'Miss', 'lot': lot, 'sub_act_id': sub_act_id}
    r.rpush(key, json.dumps(event))


def Cancel(act_id, sub_act_id, lot):
    r = get_redis()
    key = 'auction_live-%s' % act_id
    event = {'event_type': 'Cancel', 'lot': lot, 'sub_act_id': sub_act_id}
    r.rpush(key, json.dumps(event))


def GetRecordFromRedis(act_id):
    r = get_redis()
    key = 'auction_live-%s' % act_id
    _, record = r.blpop(key)
    if record:
        return [json.loads(record)]
    else:
        return []


def MarkRecordSuccess(act_id, bid):
    r = get_redis()
    key = 'success_auction_live-%s' % act_id
    r.lpush(key, json.dumps(bid))


def AddRecordBack(act_id, bid):
    r = get_redis()
    key = 'auction_live-%s' % act_id
    r.rpush(key, json.dumps(bid))


def clear_redis():
    r = get_redis()
    r.flushall()
