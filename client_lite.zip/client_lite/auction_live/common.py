# encoding: UTF-8

import os
import glob
import re

import wx

from config import base_dir, img_dir

def lot_image_path(lot):
  return os.path.join(base_dir, 'data', 'antique_images', '%s.jpg' % lot)

## def lot_image(lot):
##   if lot:
##     path = lot_image_path("%d_live" % lot)
##     if not os.path.exists(path):
##       path = lot_image_path("%d" % lot)
##       if not os.path.exists(path):
##         path = os.path.join(img_dir, 'antique_placeholder.jpg')
##   else:
##     path = os.path.join(img_dir, 'antique_placeholder.jpg')
##   return wx.Bitmap(path, wx.BITMAP_TYPE_JPEG)

def lot_image(lot):
  if lot:
    path = lot_image_path("%d_live" % lot)
    if not os.path.exists(path):
      path = lot_image_path("%d%d_live" % (0,lot))
      if not os.path.exists(path):
        path = lot_image_path("%d%d%d_live" % (0, 0, lot))
        if not os.path.exists(path):
          path = lot_image_path("%d" % lot)
          if not os.path.exists(path):
            path = lot_image_path("%d%d" % (0, lot))
            if not os.path.exists(path):
              path = lot_image_path("%d%d%d" % (0, 0, lot))
              if not os.path.exists(path):
                path = os.path.join(img_dir, 'antique_placeholder.jpg')
  else:
    path = os.path.join(img_dir, 'antique_placeholder.jpg')
  return wx.Bitmap(path, wx.BITMAP_TYPE_JPEG)

def img_scale(img, parent_size):
  if type(img) == wx.Bitmap:
    img = img.ConvertToImage()
  img_width = img.GetWidth()
  img_height = img.GetHeight()

  width_scale_factor = parent_size[0] * 1.0 / img_width
  height_scale_factor = parent_size[1] * 1.0 / img_height
  scale_factor = min(width_scale_factor, height_scale_factor)

  dest_width = scale_factor * img_width
  dest_height = scale_factor * img_height
  img.Rescale(dest_width, dest_height)

  return img.ConvertToBitmap()

def is_vertical(img):
  return 1.0*img.GetWidth()/img.GetHeight() > 1.5

def convert_img():
  path_pat = lot_image_path('*')
  names = [os.path.splitext(os.path.basename(f))[0] for f in
           glob.glob(path_pat)]
  names = [n for n in names if re.match(r'^\d+$', n)]
  total = len(names)
  print u'共有%s个图片需要处理' % total
  counter = 0
  for lot in names:
    counter += 1
    converted_path = lot_image_path("%s_live" % lot)
    if os.path.exists(converted_path):
      print u'[SKIPPED] %s/%s 图录号%s的图片已经转化过，跳过' % \
          (counter, total, lot)
      continue

    path = lot_image_path(lot)
    img = wx.Image(path, wx.BITMAP_TYPE_JPEG)
    if is_vertical(img):
      img = img_scale(img, (937, 327))
    else:
      img = img_scale(img, (448, 593))
    img.SaveFile(converted_path, wx.BITMAP_TYPE_JPEG)
    print u'[DONE] %s/%s 图录号%s的图片转化完成!' % (counter, total, lot)

