# encoding: UTF-8

import os
import time

import wx

from common import *
from lib.utils import money_amount_to_s
import config

from lib.draw_helper import DrawHelper
from lib.img_utils import img_scale

import sys
reload(sys)
sys.setdefaultencoding('utf-8')

class SlideFrame(wx.Frame):
  def __init__(self, *args, **kwargs):
    super(SlideFrame, self).__init__(*args, **kwargs)

    mbar = wx.MenuBar()
    the_menu = wx.Menu()
    fullscreenMI = the_menu.Append(wx.ID_ANY, u"全屏\tCtrl-F", u"切换全屏模式")
    mbar.Append(the_menu, u'控制')
    self.SetMenuBar(mbar)

    self.Bind(wx.EVT_MENU, self.OnFullScreen, id=fullscreenMI.GetId())

    accel_tbl = wx.AcceleratorTable([
      (wx.ACCEL_CTRL,  ord('F'), fullscreenMI.GetId()),
      #(wx.ACCEL_NORMAL,  wx.WXK_ESCAPE, fullscreenMI.GetId()),
    ])
    self.SetAcceleratorTable(accel_tbl)

    self.panel = SlidePanel(self)
    sizer = wx.BoxSizer(wx.VERTICAL)
    sizer.Add(self.panel, 1, wx.EXPAND)
    self.SetSizer(sizer)

  def OnFullScreen(self, evt):
    flags = wx.FULLSCREEN_ALL
    self.ShowFullScreen(not self.IsFullScreen(), flags)

  def OnExchangeRateChanged(self, rate):
    self.panel.OnExchangeRateChanged(rate)

  def OnAntiqueChanged(self, antique, next_antique):
    self.panel.OnAntiqueChanged(antique, next_antique)

  def OnSubActChanged(self, act, sub_act):
    self.panel.OnSubActChanged(act, sub_act)

  def OnPriceChanged(self, price):
    self.panel.OnPriceChanged(price)

  def OnSummaryChanged(self, total_count, pending_count):
    self.panel.OnSummaryChanged(total_count, pending_count)

class SlidePanel(wx.Panel, DrawHelper):
  def __init__(self, parent):
    wx.Panel.__init__(self, parent)
    self.title = u'北京诚轩拍卖有限公司'
    self.price = None
    self.total_count = u'---'
    self.pending_count = u'---'
    self.antique = {}
    self.next_antique = {}
    self.exchange_rate = {}

    self.pageWidth = None
    self.pageHeight = None
    self.Bind(wx.EVT_PAINT, self.OnPaint)

    vbkgd_path = os.path.join(config.img_dir, "vertical-layout.jpg")
    self.vbkgd_bm = wx.Bitmap(vbkgd_path, wx.BITMAP_TYPE_JPEG)
    hbkgd_path = os.path.join(config.img_dir, "horizontal-layout.jpg")
    self.hbkgd_bm = wx.Bitmap(hbkgd_path, wx.BITMAP_TYPE_JPEG)

    self.timer = wx.Timer(self)
    self.Bind(wx.EVT_TIMER, self.OnTimer)
    self.timer.Start(5000)

  def OnExchangeRateChanged(self, rate):
    self.exchange_rate = rate

  def OnAntiqueChanged(self, antique, next_antique):
    self.antique = antique
    self.next_antique = next_antique
    self.price = None
    self.Refresh()

  def OnSubActChanged(self, act, sub_act):
    self.title = sub_act.get('name', '---').decode('utf-8')
    print 'title:', self.title
    #self.title = u' > '.join((u'北京诚轩拍卖有限公司',
                              #act.get('name', '---').decode('utf-8'),
                              #sub_act.get('name', '---').decode('utf-8')))
    self.Refresh()

  def OnPriceChanged(self, price):
    self.price = price
    self.Refresh()

  def OnSummaryChanged(self, total_count, pending_count):
    self.total_count = total_count
    self.pending_count = pending_count
    self.Refresh()

  def OnTimer(self, evt):
    self.Refresh()

  def OnPaint(self, evt):
    dc = wx.PaintDC(self)
    dc.SetBackground(wx.Brush("WHITE"))
    dc.Clear()

    self.pageWidth, self.pageHeight = dc.GetSize()

    img = lot_image(self.antique.get('lot', None))
    if is_vertical(img):
      self.PaintVertical(dc, img)
    else:
      self.PaintHorizontal(dc, img)

  def PaintHorizontal(self, dc, img):
    if config.convert_img_on_fly:
      img = img_scale(img, (448, 593))

    ch_font_style = { 'name': u'宋体', 'size': 18 }
    self.default_style = {'style': {'font': ch_font_style}}

    # draw background image
    format_data = [
      {'type': 'image', 'image': self.hbkgd_bm,
       'position': {'x': 0, 'y': 0}},
    ]

    format_data += [
      {'type': 'image', 'image': img,
       'position': {'x': 39, 'y': 133, 'width': 448, 'height': 593},
       'style': {'align': 'center', 'valign': 'center'}},
      ]

    format_data += self.DrawDateTime()

    format_data += self.DrawSubActInfo()

    format_data += self.DrawLot(552, 130)

    format_data += self.DrawAntiqueInfo(552, 210)

    format_data += self.DrawPriceLines()
    #self.DrawNextAntique(info_x)

    self.data = [d for d in format_data if d]
    self.DrawFormatData(dc)

  def PaintVertical(self, dc, img):
    if config.convert_img_on_fly:
      img = img_scale(img, (937, 328))

    ch_font_style = { 'name': u'宋体', 'size': 18 }
    self.default_style = {'style': {'font': ch_font_style}}

    # draw background image
    format_data = [
      {'type': 'image', 'image': self.vbkgd_bm,
       'position': {'x': 0, 'y': 0}},
    ]

    format_data += [
      {'type': 'image', 'image': img,
       'position': {'x': 43, 'y': 131, 'width': 937, 'height': 328},
       'style': {'align': 'center', 'valign': 'center'}},
      ]

    format_data += self.DrawDateTime()

    format_data += self.DrawSubActInfo()

    format_data += self.DrawLot(43, 512)

    format_data += self.DrawAntiqueInfo(43, 560)

    format_data += self.DrawPriceLines()
    #self.DrawNextAntique(info_x)

    self.data = [d for d in format_data if d]
    self.DrawFormatData(dc)

  def GetBasePos(self):
    return 0, 0

  def GetAttr(self, attr, default=None):
    return self.antique.get(attr, default) or default

  def GetPrice(self, exchange=None):
    if self.price is None:
      return None

    if not exchange:
      return int(self.price)
    else:
      rate = float(self.exchange_rate.get(exchange, 1))
      return int(self.price/rate)

  def DrawPriceLine(self, price, y):
    format_data = []
    if not price:
      return format_data

    x_start = 650
    width = 316
    font_style = { 'name': u'Myriad Pro Semibold', 'size': 42 }
    #format_data += [
      #{'text': money_amount_to_s(price),
       #'position': {'x': x_start, 'y': y, 'width': width},
       #'style': {'align': 'right', 'font': font_style},}
    #]

    format_data += [
      {'type': 'label', 'text': money_amount_to_s(price),
       'position': {'x': x_start, 'y': y, 'width': width},
       'style': {'align': 'right', 'font': font_style, 'span': 5}},
      ]

    return format_data

  def DrawPriceLineOld(self, price, y):
    format_data = []
    if not price:
      return format_data

    x_start = 938
    span = 38
    width = 31
    font_style = { 'name': u'Times', 'size': 26 }
    digits = reversed(list(str(price)))
    for d in digits:
      format_data += [
        {'text': str(d),
         'position': {'x': x_start, 'y': y, 'width': width},
         'style': {'align': 'center', 'font': font_style}}
      ]
      x_start -= span
    return format_data

  def DrawPriceLines(self):
    format_data = []
    line_y = 54
    y_start = 514
    format_data += self.DrawPriceLine(self.GetPrice(), y_start)

    y_start += line_y
    format_data += self.DrawPriceLine(self.GetPrice('hkd'), y_start)

    y_start += line_y
    format_data += self.DrawPriceLine(self.GetPrice('usd'), y_start)

    y_start += line_y
    format_data += self.DrawPriceLine(self.GetPrice('eur'), y_start)

    return format_data

  def DrawNextAntique(self, info_x):
    medium_font_style = { 'name': u'宋体', 'size': 12 }

    next_img = lot_image(self.next_antique.get('lot', None))
    if config.convert_img_on_fly:
      next_img = img_scale(next_img, (100, 100))

    format_data = [
      {'type': 'region',
       'position': {'x': info_x, 'y': '76%', 'width': 100, 'height':
                    next_img.GetHeight()+40},
       'style': {'color': wx.Colour(200, 200, 200)}}
    ]

    format_data += [
      {'text': u'下一件 Lot. %s' % self.next_antique.get('lot', '---'),
       'position': {'x': info_x, 'y': '77%', 'width': 100},
       'style': {'align': 'center', 'font': medium_font_style}},
      ]

    format_data += [
      {'type': 'image', 'image': next_img.ConvertToBitmap(),
       'position': {'x': info_x, 'y': '80%', 'width': 100},
       'style': {'align': 'center', 'font': medium_font_style}},
      ]

    txt_elems = [self.next_antique.get('author', None),
                 self.next_antique.get('age', None),
                 self.next_antique.get('name', None),]
    format_data += [
      {'text': tuple(elem.strip().decode('utf-8') for elem in txt_elems if elem),
       'position': {'x': 850, 'y': '80%', 'width': '18%'},
       'style': {'space': 3, 'font': medium_font_style, 'wrap': True}},
    ]
    return format_data

  def DrawSubActInfo(self):
    format_data = []

    format_data += [
      {'text': self.title,
       'position': {'x': 400, 'y': 66, 'width': 200},
       'style': {'align': 'right',
                 #'font': {'name': u'Microsoft YaHei Bold', 'size': 30},
                 'font': {'name': u'Microsoft YaHei', 'size': 27},
                 'color': (150,110,55) },
      }
    ]

    format_data += [
      {'text': u'本场拍品：%s件    尚待拍卖：%s件' % (self.total_count,
                                                  self.pending_count),
       'position': {'x': 700, 'y': 75, 'width': 284},
       'style': {'align': 'right',
                 'font': {'name': u'Microsoft YaHei', 'size': 20},
                },
      }
    ]
    return format_data

  def DrawDateTime(self):
    format_data = []
    format_data += [
      {'text': time.strftime('%Y-%m-%d'),
       'position': {'x': 775, 'y': 50, 'width': 189},
       'style': {'font': {'name': u'Microsoft YaHei', 'size': 15},
                 'align': 'left'}},
    ]

    format_data += [
      {'text': time.strftime('%H:%M'),
       'position': {'x': 800, 'y': 37, 'width': 184},
       'style': {'font': {'name': u'Myriad Pro Regular', 'size': 30},
                 'align': 'right'}},
    ]
    return format_data

  def DrawLot(self, x, y):
    return [
      {'text': "Lot %s" % self.GetAttr('lot', '---'),
       'position': {'x': x, 'y': y},
       'style': {'font': {'name': u'Myriad Pro Semibold', 'size': 44},
                 'color': (150,110,55)}},
    ]

  def DrawAntiqueInfo(self, x, y, width=450):
    if self.GetAttr('name2', '') and self.GetAttr('author2', ''):
      line1 = ''
      line2 = ''
      line3 = ''
      if self.GetAttr('author', ''):
        line1 += self.GetAttr('author', '') + ' '
      line1 += self.GetAttr('name', '')
      if self.GetAttr('age', ''):
        #line1 += self.GetAttr('age', '') + ' '
        line3 =  self.GetAttr('age', '')
      #line1 += self.GetAttr('name', '')
      line2 = self.GetAttr('author2', '')+' '+self.GetAttr('name2', '')
      txt_elems = [line1, line2, line3]
    else:
      txt_elems = [self.GetAttr('author'), self.GetAttr('name'),
                   self.GetAttr('age')]

    txt = tuple(elem.strip().decode('utf-8') for elem in txt_elems if elem)
    print ''
    wrap = True
    for item in txt:
      if item.count('\n'):
        wrap = False

    return [
      {'text': txt,
       'position': {'x': x, 'y': y, 'width': width},
       'style': {'wrap': wrap,
                 'font': {'name': u'Microsoft YaHei Bold', 'size': 35}}},
    ]

  def DrawLabelElement(self, dc, elem):
    x0, y0 = self.GetBasePos()
    style = elem.get('style', {})
    font = style.get('font', None)
    if font:
      self.ApplyFont(dc, font)
    else:
      self.ResetFont(dc)

    color = style.get('color', None)
    if color:
      dc.SetTextForeground(color)
    else:
      dc.SetTextForeground(wx.BLACK)

    text  = elem['text']
    span = style.get('span', 0)
    #parts = re.findall(r'(\d,?)', text)
    parts = list(text)
    txt_width = dc.GetTextExtent(text)[0] + span*max(0, len(parts)-1)

    pos = elem['position']
    xoffset = max(0, self.GetAbsPos(pos['width'], self.pageWidth) - txt_width)
    x = x0 + self.GetAbsPos(pos['x'], self.pageWidth) + xoffset
    y = y0 + self.GetAbsPos(pos['y'], self.pageHeight)

    for part in parts:
      dc.DrawText(part, x, y)
      x += span + dc.GetTextExtent(part)[0]

