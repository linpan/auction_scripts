# encoding: UTF-8

import os
import wx

import config

class BitmapButtonEx(wx.BitmapButton):
  def __init__(self, bmp_name, *args, **kwargs):
    ext_name = os.path.splitext(bmp_name)[1][1:]
    bm_type = eval('wx.BITMAP_TYPE_%s' % ext_name.upper())
    bmp = wx.Bitmap(os.path.join(config.img_dir, bmp_name), bm_type)
    btn_size = (bmp.GetWidth()+18, bmp.GetHeight()+4)
    new_kwargs = {'bitmap': bmp, 'size': btn_size}
    new_kwargs.update(kwargs)
    wx.BitmapButton.__init__(self, *args, **new_kwargs)
