# encoding: UTF-8

import re
import wx
from types import *

class ValidatorHelperMixin:
  def MarkError(self):
    ctrl = self.GetWindow()
    ctrl.SetBackgroundColour("pink")
    ctrl.SetFocus()
    ctrl.Refresh()

  def Restore(self):
    ctrl = self.GetWindow()
    ctrl.SetBackgroundColour(wx.SystemSettings_GetColour(wx.SYS_COLOUR_WINDOW))
    ctrl.Refresh()

class PureTransferValidatorMixin:
  def DoValidate(self):
    return True

class NotEmptyValidatorMixin:
  def DoValidate(self):
    ctrl = self.GetWindow()
    val = ctrl.GetValue()
    return len(val.strip()) > 0

class NumberValidatorMixin:
  def DoValidate(self):
    ctrl = self.GetWindow()
    val = ctrl.GetValue()
    if len(val.strip()) == 0:
      if self.allow_empty: return True
      else: return False

    if not re.match('^-?\d+(\.\d+)?$', val.strip()):
      return False

    fval = float(val.strip())

    if self.min_val is not None and fval <= self.min_val:
      return False

    if self.max_val is not None and fval >= self.max_val:
      return False

    return True

class BaseValidator(wx.PyValidator, ValidatorHelperMixin):
  def __init__(self, dict_data=None, key=None, conv_handler=None,
               translator=None, allow_empty=True, min_val=None, max_val=None):
    wx.PyValidator.__init__(self)
    self.dict_data = dict_data
    self.key = key
    self.conv_handler = conv_handler
    self.translator = translator
    self.allow_empty = allow_empty
    self.min_val = min_val
    self.max_val = max_val

  def Clone(self):
    return self.__class__(self.dict_data, self.key,
                          self.conv_handler,
                          self.translator,
                          self.allow_empty,
                          self.min_val,
                          self.max_val)

  def Validate(self, win):
    result = self.DoValidate()
    if result:
      self.Restore()
    else:
      self.MarkError()
    return result

  def TransferToWindow(self):
    ctrl = self.GetWindow()
    val  = self.dict_data.get(self.key, u'')
    if val is None:
      val = u''
    if type(ctrl) == wx.Choice:
      ctrl.SetStringSelection(val)
    elif type(ctrl) == wx.RadioBox:
      ctrl.SetStringSelection(val)
    else:
      if self.translator:
        val = self.translator(val, True)

      if type(val) is UnicodeType or type(val) is StringType:
        ctrl.SetValue(val)
      else:
        ctrl.SetValue(str(val))

    return True

  def TransferFromWindow(self):
    ctrl = self.GetWindow()
    if type(ctrl) == wx.Choice:
      val = ctrl.GetStringSelection().strip()
    elif type(ctrl) == wx.RadioBox:
      val = ctrl.GetStringSelection().strip()
    else:
      val = ctrl.GetValue().strip()
    if len(val):
      if self.translator:
        val = self.translator(val, False)

      if self.conv_handler:
        self.dict_data[self.key] = self.conv_handler(val)
      else:
        self.dict_data[self.key] = val
    #FIXME: can not delete from value, need to verify
    else:
      self.dict_data[self.key] = None
    return True

__validators = {}

def GetValidator(mixin):
  cached = __validators.get(mixin.__name__, None)
  if not cached:
    cached = type('Validator_%s' % mixin.__name__, (BaseValidator, mixin), {})
    __validators[mixin.__name__] = cached
  return cached


