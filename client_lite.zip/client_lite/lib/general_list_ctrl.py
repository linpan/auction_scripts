# encoding: UTF-8

import sys
import types
import copy
import wx
import  wx.lib.mixins.listctrl as listmix

from lib.base_list_ctrl_mixin import BaseListCtrlMixin

class GeneralListCtrlMixin(BaseListCtrlMixin):
  def DoInit(self, col_infos):
    '''
    col_infos is a list of tuple [(name, key, preprocessor, postprocessor), ... ]
    '''
    self.col_infos = [dict(zip(('name', 'key', 'preprocessor', 'postprocessor'), info)) for info in col_infos]
    for i, info in enumerate(self.col_infos):
      self.InsertColumn(i, info['name'])
    self.datas = []

  def PopulateData(self, data):
    self.DeleteAllItems()
    if isinstance(data, list):
      self.datas = data
    else:
      self.datas = [data]
    [self._InsertRow(d, i) for i, d in enumerate(self.datas)]
    self.Refresh()

  def GetDataFromItem(self, item):
    if self.GetItemCount() == 0:
      return None

    if item is not None:
      index = self.GetItemData(item)
      return self.datas[index]

  def GetSelectedItemData(self):
    item = self.GetSelectedItem()
    return self.GetDataFromItem(item)

  def _GetValue(self, row, key, preprocessor=None):
    if key is None: return ''
    val = reduce(lambda r,k: r is not None and r.get(k, None), key.split('.'), row)
    if val is None:
      return ''
    if preprocessor:
      val = preprocessor(val)
    if type(val) == types.StringType:
      val = val.decode('utf-8')
    return val

  def UpdateRow(self, item, new_data):
    data_index = self.GetItemData(item)
    self.datas[data_index] = copy.deepcopy(new_data)
    for i, info in enumerate(self.col_infos):
      val = self._GetValue(new_data, info['key'],
                           info.get('preprocessor', None))
      val = u"%s" % val
      self.SetStringItem(item, i, val)
      post_proc = info.get('postprocessor', None)
      if post_proc:
        post_proc(self, item, val)

    self.OnAfterRowInserted(item, new_data)

  def _InsertRow(self, row, custom_data):
    index = None
    for i, info in enumerate(self.col_infos):
      val = self._GetValue(row, info['key'], info.get('preprocessor', None))
      val = u"%s" % val
      if i == 0:
        index = self.InsertStringItem(sys.maxint, val)
        self.SetItemData(index, custom_data)
      else:
        self.SetStringItem(index, i, val)
      post_proc = info.get('postprocessor', None)
      if post_proc:
        post_proc(self, index, val)

    self.OnAfterRowInserted(index, row)

  def OnAfterRowInserted(self, index, row):
    pass

  def FilterItem(self, filter_str, col_index=0):
    for i in xrange(self.GetItemCount()):
      if self.GetColumnText(i, col_index) == filter_str:
        self.SetItemTextColour(i, wx.BLUE)
        self.EnsureVisible(i)
      else:
        self.SetItemTextColour(i, wx.BLACK)

  def IterateItems(self, filter_str, col_index=0):
    for i in xrange(self.GetItemCount()):
      if filter_str in self.GetColumnText(i, col_index):
        yield i

  def SelectItemByCol(self, filter_str, col_index=0, start_row=-1,
                      partial_match=True):
    filter_str = filter_str.lower()
    for i in xrange(self.GetItemCount()):
      row_index = (i+start_row+1) %  self.GetItemCount()
      if partial_match:
        if filter_str in self.GetColumnText(row_index, col_index).lower():
          self.SelectItem(row_index)
          return row_index
      else:
        if filter_str == self.GetColumnText(row_index, col_index).lower():
          self.SelectItem(row_index)
          return row_index

  def FilterItemByData(self, filters, start=-1, select_all=True):
    if not filters: return
    for i, d in enumerate(self.datas):
      bAll = True
      for k,v in filters.iteritems():
        kval = self._GetValue(d, k)
        if type(v) == types.FunctionType:
          bAll = bAll and v(kval)
        else:
          bAll = bAll and kval == v
        if not bAll: break
      if bAll:
        item = self.FindItemData(start, i)
        if item is not None: yield item
        if not select_all: return

  def SelectItemByData(self, filters, start=-1, select_all=True):
    items = self.FilterItemByData(filters, start, select_all)
    items_list = tuple(items)
    for item in items_list: self.SelectItem(item)
    return items_list

  def SelectAll(self):
    for i in range(self.GetItemCount()):
      self.SelectItem(i)

  def SelectCancel(self):
    [self.UnselectItem(i) for i in range(self.GetItemCount())
     if self.IsItemSelected(i)]

  def SelectInversed(self):
    for i in range(self.GetItemCount()):
      if self.IsItemSelected(i):
        self.UnselectItem(i)
      else:
        self.SelectItem(i)

class GeneralListCtrl(wx.ListCtrl, GeneralListCtrlMixin,
                      listmix.ListCtrlAutoWidthMixin):
  def __init__(self, parent, ID=wx.ID_ANY, pos=wx.DefaultPosition,
               size=wx.DefaultSize,
               style=wx.LC_REPORT|wx.BORDER_NONE|wx.LC_HRULES|wx.LC_VRULES):
      wx.ListCtrl.__init__(self, parent, ID, pos, size, style)

      listmix.ListCtrlAutoWidthMixin.__init__(self)

