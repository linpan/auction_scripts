# encoding: UTF-8

import math

class Rate258Price:
  def __init__(self, bit_offset):
    self.bit_offset = bit_offset
    self.error = 0.000001

  def _get_weight(self, price):
    # GOTCHA: have to add the error to math.log to handle the case when price
    # is 1000, math.log(price, 10) is 2.9999999996
    bits = int(math.log(price, 10)+self.error)
    significant_bit = bits - self.bit_offset + 1
    if significant_bit < 0:
      return None

    weight = int(math.pow(10, significant_bit)+self.error)
    return weight

  def up(self, price):
    if price <= 0:
      return 0

    weight = self._get_weight(price)
    if weight is None:
      return 0

    remainder = (price / weight) % 10

    if remainder >= 0 and remainder < 2:
      addition = (2-remainder) * weight
    elif remainder >= 2 and remainder < 5:
      addition = (5-remainder) * weight
    elif remainder >= 5 and remainder < 8:
      addition = (8-remainder) * weight
    else:
      addition = (10-remainder) * weight

    #if remainder == 0 or remainder == 8:
      #addition = 2 * weight
    #elif remainder == 2 or remainder == 5:
      #addition = 3 * weight
    #else:
      #addition = 0
    return addition

  def down(self, price):
    if price <= 0:
      return 0

    weight = self._get_weight(price)
    if weight is None:
      return 0

    remainder = (price / weight) % 10

    if remainder > 0 and remainder <= 2:
      addition = (remainder-0) * weight
    elif remainder > 2 and remainder <= 5:
      addition = (remainder-2) * weight
    elif remainder > 5 and remainder <= 8:
      addition = (remainder-5) * weight
    elif remainder == 0:
      addition = (10-8) * weight
    else:
      addition = (remainder-8) * weight

    #if remainder == 0 or remainder == 2:
      #addition = 2 * weight
    #elif remainder == 8 or remainder == 5:
      #addition = 3 * weight
    #else:
      #addition = 0
    return -1 * addition

