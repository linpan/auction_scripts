class InvalidResponseException(Exception):
  pass

class ErrorResponseException(Exception):
  pass

class FailureResponseException(Exception):
  def __init__(self, resp, *args):
    super(self.__class__, self).__init__(*args)
    self.resp = resp
