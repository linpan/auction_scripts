# encoding: UTF-8

import string
import re

numbers = [u'零', u'壹', u'貳', u'叁',  u'肆', u'伍',  u'陆', u'柒',
            u'捌', u'玖']
bases = [u'拾',  u'佰', u'仟', u'万', u'亿']

class MoneyAmountConverter:

  @classmethod
  def convert(cls, amount):
    if type(amount) != int:
      raise Exception("Invalid amount type(%s)!" % type(amount))

    chars = []

    big_part = ( amount / 10000 / 10000) % 10000
    if big_part:
      chars += cls._convert_less_10k(big_part)
      chars.append(bases[-1])

    less_10m = ( amount / 10000 ) % 10000
    if less_10m:
      chars += cls._convert_less_10k(less_10m)
      chars.append(bases[-2])

    less_10k = amount % 10000
    chars += cls._convert_less_10k(less_10k)

    value = u''.join(chars)
    value = cls._cleanup(value)

    value += u'元整'
    return value

  @classmethod
  def _cleanup(cls, value):
    value = string.strip(value, numbers[0])
    return re.sub(u'零(零+)', u'零', value)

  @classmethod
  def _convert_less_10k(cls, less_10k):
    chars = []
    num_ks = less_10k / 1000
    remainder = less_10k % 1000
    if num_ks:
      chars.append(numbers[num_ks])
      chars.append(bases[2])
    else:
      chars.append(numbers[0])

    num_hs = remainder / 100
    remainder = remainder % 100
    if num_hs:
      chars.append(numbers[num_hs])
      chars.append(bases[1])
    else:
      chars.append(numbers[0])

    num_ts = remainder / 10
    remainder = remainder % 10
    if num_ts:
      chars.append(numbers[num_ts])
      chars.append(bases[0])
    else:
      chars.append(numbers[0])

    if remainder:
      chars.append(numbers[remainder])

    while len(chars) and chars[-1] == numbers[0]:
      chars.pop()

    return chars

