# encoding: UTF-8

import os

import wx

import config

def img_scale(img, parent_size):
  if type(img) == wx.Bitmap:
    img = img.ConvertToImage()

  img_width = img.GetWidth()
  img_height = img.GetHeight()

  width_scale_factor = parent_size[0] * 1.0 / img_width
  height_scale_factor = parent_size[1] * 1.0 / img_height
  scale_factor = min(width_scale_factor, height_scale_factor)

  dest_width = scale_factor * img_width
  dest_height = scale_factor * img_height
  img.Rescale(dest_width, dest_height)

  return img.ConvertToBitmap()

def get_image(name):
  ext_name = os.path.splitext(name)[1][1:]
  bm_type = eval('wx.BITMAP_TYPE_%s' % ext_name.upper())
  path = os.path.join(config.img_dir, name)
  return wx.Bitmap(path, bm_type)
