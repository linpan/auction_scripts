# encoding: UTF-8

import os
import json
import urllib
import urllib2
from packages.restful_lib import Connection
from packages import poster

from lib.exceptions import *

import wx

import config

def conn():
  return Connection(config.base_service_url)

def response_handler(func):
  def wrapper(*args, **kwargs):
    config.get_logger().info(u'send %s request to server: %s %s' %
                             (func.__name__, args, kwargs))
    resp = func(*args, **kwargs)
    config.get_logger().info(u'finish %s request with resp headers: %s' %
                             (func.__name__, resp['headers']))

    if not resp or not resp.has_key('headers'):
      err_msg = "invalid response %s" % repr(resp)
      config.get_logger().error(err_msg)
      raise InvalidResponseException(err_msg)

    status = resp['headers'].get('status', None)
    if status == '404':
      err_msg = "resource not found error response %s" % repr(resp)
      config.get_logger().error(err_msg)
      return None

    if status == '500':
      err_msg = "internal server error response %s " % repr(resp)
      config.get_logger().error(err_msg)
      raise ErrorResponseException(err_msg)

    js = json.loads(resp['body'])
    if js and js.has_key('status') and int(js['status']) == 1:
      err_msg = "got failure response %s" % repr(resp)
      config.get_logger().error(err_msg)
      wx.MessageBox(err_msg, u'服务器错误信息', wx.OK|wx.ICON_ERROR)
      raise FailureResponseException(js, err_msg)
    else:
      return js
  return wrapper

def clean_none_values(args):
  if not args:
    return
  for k in args.keys():
    if args[k] is None:
      del args[k]

@response_handler
def get(resource, args=None, headers={'cache-control': 'no-cache'}):
  return conn().request_get(resource, args, headers)

@response_handler
def post(resource, args = None, body = None, filename=None, headers=None):
  headers = headers or {}
  clean_none_values(args)
  if not body:
    headers['Content-Length'] = '0' # workaround nginx content-length issue
  return conn().request_post(resource, args, body, filename, headers)

@response_handler
def put(resource, args = None, body = None, filename=None, headers=None):
  headers = headers or {}
  clean_none_values(args)
  if not body:
    headers['Content-Length'] = '0' # workaround nginx content-length issue
  return conn().request_put(resource, args, body, filename, headers)

@response_handler
def delete(resource, args=None, headers={}):
  return conn().request_delete(resource, args, headers)

def upload_files(url, file_infos):
  if not file_infos: return

  if not url.startswith('http'):
    url = config.base_service_url + url

  poster.streaminghttp.register_openers()
  encoded_info = dict([(name, open(path, 'rb')) for name, path in file_infos])
  datagen, headers =  poster.encode.multipart_encode(encoded_info)
  req = urllib2.Request(url, datagen, headers)
  return urllib2.urlopen(req)

def download_image(url, dest_file_path):
  r = download_file(url, dest_file_path)
  if r[1].maintype != 'image':
    os.remove(dest_file_path)
    return False
  return True

def download_file(url, dest_file_path):
  if not url.startswith('http'):
    url = config.base_service_url + url
  return urllib.urlretrieve(url, dest_file_path)
