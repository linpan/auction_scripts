# encoding: UTF-8

from rest_client import *

def create_transaction():
  post("/activity/%s/sub_activity/%s/transactions" % (1, 1),
       {'lot': 6, 'reg_num': 1, 'price': 20000})
  post("/activity/%s/sub_activity/%s/transactions" % (1, 1),
       {'lot': 7, 'reg_num': 1, 'price': 30000})
  post("/activity/%s/sub_activity/%s/transactions" % (1, 1),
       {'lot': 8, 'reg_num': 1, 'price': 40000})
