#encoding: utf-8

"""
IDR device homesite: www.idiway.com

sdk document: http://www.docin.com/p-117651470.html
installation doc: http://www.docin.com/p-540520.html
"""

import os
import time
from ctypes import *

import wx

from lib.utils import gen_person_photo_dir

import config

class HY_RECT_S(Structure):
  ''' 身份证OCR '''
  _fields_ = [
    ('lLeft',  c_long),
    ('lRight', c_long),
    ('lTop',   c_long),
    ('lBottom',c_long),
  ]

class ID_CARD_S(Structure):
  _fields_ = [
    ('szText', (c_char*256)*10),
    ('idRect', HY_RECT_S*10),
  ]

  def generate_card_info(self, info):
    for i, n in [(1, 'Name'), (2, 'Sex'), (3, 'BirthDate'),
                 (4, 'Nation'), (7, 'Address'), (8, 'ID'),
                 (5, 'StartDate'), (6, 'EndDate'),
                 (None, 'FromDepart'), (None, 'NewAddress')]:
      if i is None:
        value = ''
      else:
        value = self.szText[i].value
      setattr(info, n, value)

class JL_ITEM(Structure):
  ''' 护照OCR '''
  _fields_ = [
    ('pzTxt', c_char*256),
    ('left',   c_long),
    ('top',    c_long),
    ('right',  c_long),
    ('bottom', c_long),
  ]

class CardInfo:
  ID_VER1 = 1
  ID_VER2 = 2
  PASSPORT = 5
  OTHER = 99

  def __init__(self, card_type, act_id=0, person_id=None):
    self.card_type = card_type
    self.act_id = act_id
    self.person_id = person_id or self.tmp_person_id()
    self.filter_photo = self._gen_photo_path('filter')
    self.full_photo = self._gen_photo_path('full')
    self.head_photo = self._gen_photo_path('head')
    self.back_photo = self._gen_photo_path('back')
    self.placeholder_photo = self._gen_photo_path('placeholder')

  def dump(self):
    print "card_type: %d, person_id: %s" % (self.card_type, self.person_id)
    fields = ['Name', 'Sex', 'Nation', 'BirthDate',
              'Address', 'ID', 'FromDepart', 'StartDate',
              'EndDate', 'NewAddress']
    for f in fields:
      print "%s: %s" % (f, getattr(self, f, ''))
    print 'filter_photo_path: %s' % self.filter_photo
    print 'full_photo_path: %s' % self.full_photo
    print 'head_photo_path: %s' % self.head_photo
    print 'back_photo_path: %s' % self.back_photo
    print 'placeholder_photo_path: %s' % self.placeholder_photo

  def tmp_person_id(self):
    return 'tmp_%s' % int(time.time())

  def _gen_photo_path(self, file_name):
    dir_path = gen_person_photo_dir(self.act_id, self.person_id)
    return os.path.join(dir_path, file_name + '.bmp')

class TermbItem(Structure):
  _fields_ = [('pzTxt', (c_char*128)*70)]

  def generate_card_info(self, info):
    for i, n in enumerate(['Name', 'Sex', 'Nation', 'BirthDate',
              'Address', 'ID', 'FromDepart', 'StartDate',
                           'EndDate', 'NewAddress']):
      setattr(info, n, self.pzTxt[i].value)

class IDRCore:
  def __init__(self):
    self.dll = None

  def ConvertBmpToJpg(self, card_info):
    for attr,width, height in [('full_photo', 320, 240),
                              ('back_photo', 320, 240),
                              ('head_photo', 105, 130)]:
      bmp = getattr(card_info, attr)
      if not os.path.exists(bmp): continue

      if attr == 'back_photo':
        img = wx.Image(bmp, wx.BITMAP_TYPE_BMP)
        img.GetSubImage(wx.Rect(img.GetWidth()-904, 0, 904, 593))\
            .SaveFile(bmp, wx.BITMAP_TYPE_BMP)

      jpg = os.path.splitext(bmp)[0] + '.jpg'
      self.BmpToJpg2(bmp, jpg, width, height)
      setattr(card_info, 'jpg_'+attr, jpg)

  def ReadCardInfoByIC(self, card_info):
    self.open_device()

    iResult = 0
    sleep_time = 0.5
    loops = int(config.idr_wait_time_in_second/sleep_time)
    for i in range(loops):
      iResult = self.Get_TermbData(card_info, card_info.full_photo)
      if iResult == 0:
        break
      else:
        time.sleep(sleep_time)

    if iResult == 0: return iResult
    raise Exception(self.Format_ErrMsg(iResult))

  def ReadCardInfoByOCR(self, card_info):
    self.open_device()

    iResult = self.Get_IdcPic(card_info.card_type,
                              card_info.filter_photo)

    if iResult != 0:
      raise Exception(self.Format_ErrMsg(iResult))

    ## iResult = self.Get_IdcData(card_info,
    ##                            card_info.filter_photo)
    ## if iResult != 0:
    ##   raise Exception(self.Format_ErrMsg(iResult))

    iResult = self.Get_ColorPic(card_info.card_type,
                                card_info.full_photo,
                                card_info.head_photo)
    if iResult != 0:
      raise Exception(self.Format_ErrMsg(iResult))

    return iResult

  def ReadOtherCardInfoByOCR(self, card_info):
    self.open_device()

    iResult = self.Get_MiscPic(card_info.card_type,
                              card_info.filter_photo)
    if iResult != 0:
      raise Exception(self.Format_ErrMsg(iResult))

    iResult = self.Get_MiscData(card_info,
                               card_info.filter_photo)
    if iResult != 0:
      raise Exception(self.Format_ErrMsg(iResult))

    iResult = self.Get_ColorPic(card_info.card_type,
                                card_info.full_photo,
                                card_info.head_photo)
    if iResult != 0:
      raise Exception(self.Format_ErrMsg(iResult))

    return iResult

  def ScanPic(self, card_info, back=False):
    self.open_device()

    if back:
      iResult = self.Get_ColorPic(CardInfo.OTHER,
                                  card_info.back_photo,
                                  card_info.placeholder_photo)
    else:
      iResult = self.Get_ColorPic(CardInfo.OTHER,
                                  card_info.full_photo,
                                  card_info.placeholder_photo)

    if iResult != 0:
      raise Exception(self.Format_ErrMsg(iResult))

    return iResult

  def get_dll(self):
    if self.dll is None:
      self.dll = WinDLL(os.path.join(config.idr_base_dir, 'Dll', 'IDRCore.dll'))

    return self.dll

  def open_device(self):
    if not self.Device_IsOpen():
      self.Device_Open()
    if not self.Device_IsOpen():
      raise Exception(u'设备打开失败，请确认设备连接正常并已经打开电源！')

  def Device_IsOpen(self):
    '''设备是否已打开'''
    return self.get_dll().Device_IsOpen() == 1

  def Device_IsCanReadTwoCard(self):
    '''是否安装二代证模块'''
    return self.get_dll().Device_IsCanReadTwoCard()

  def Device_Open(self):
    return self.get_dll().Device_Open()

  def Device_Close(self):
    return self.get_dll().Device_Close()

  def Get_TermbData(self, card_info, szFileName):
    '''机读二代证'''
    pszFileName = c_char_p(szFileName)

    termb_item = TermbItem()
    iResult = self.get_dll().Get_TermbData(pszFileName, byref(termb_item))
    if iResult == 0:
      termb_item.generate_card_info(card_info)
    return iResult

  def Get_IdcPic(self, iCardType, szFileNameIn):
    '''解析身份证图片'''
    pszFileNameIn = c_char_p(szFileNameIn)
    return self.get_dll().Get_IdcPic(iCardType, pszFileNameIn)

  def Get_IdcData(self, card_info, szFileNameIn):
    '''解析身份证信息'''
    pszFileNameIn = c_char_p(szFileNameIn)
    id_card_s = ID_CARD_S()
    iResult = self.get_dll().Get_IdcData(card_info.card_type, pszFileNameIn,
                                         '', '', byref(id_card_s))
    if iResult == 0:
      id_card_s.generate_card_info(card_info)
    return iResult

  def Get_MiscPic(self, iCardType, szFileNameIn):
    '''解析其它证件图片'''
    pszFileNameIn = c_char_p(szFileNameIn)
    return self.get_dll().Get_MiscPic(iCardType, pszFileNameIn)

  def Get_MiscData(self, card_info, szFileNameIn):
    '''解析其它证件信息'''
    pszFileNameIn = c_char_p(szFileNameIn)
    JL_ITEMS = JL_ITEM * 256
    items = JL_ITEMS()
    return self.get_dll().Get_MiscData(card_info.card_type, pszFileNameIn,
                                      '', '', byref(items))
  def Get_ColorPic(self, iCardType, szFullFileNameOut, szHeadFileNameOut):
    '''拍彩色证面照'''
    pszFullFileNameOut = c_char_p(szFullFileNameOut)
    pszHeadFileNameOut = c_char_p(szHeadFileNameOut)
    return self.get_dll().Get_ColorPic(iCardType, pszFullFileNameOut,
                                       pszHeadFileNameOut)

  def BmpToJpg(self, szFileNameSrc, szFileNameDest):
    '''Bmp转换成Jpg'''
    pszFileNameSrc = c_char_p(szFileNameSrc)
    pszFileNameDest = c_char_p(szFileNameDest)
    return self.get_dll().BmpToJpg(pszFileNameSrc, pszFileNameDest)

  def BmpToJpg2(self, szFileNameSrc, szFileNameDest, iWidth, iHeight):
    '''Bmp转换成Jpg'''
    pszFileNameSrc = c_char_p(szFileNameSrc)
    pszFileNameDest = c_char_p(szFileNameDest)
    return self.get_dll().BmpToJpg2(pszFileNameSrc, pszFileNameDest,
                                    iWidth, iHeight)

  def Show_ConfigWindow(self, iCardType):
    '''显示配置窗口'''
    return self.get_dll().Show_ConfigWindow(None, iCardType)

  def Format_ErrMsg(self, iErrCodeIn):
    '''显示错误消息'''
    buf = '\0'*1024
    perr_msg = c_char_p()
    perr_msg.value = buf
    self.get_dll().Format_ErrMsg(iErrCodeIn, byref(perr_msg))
    return perr_msg.value

_idr = None
def get_idr():
  global _idr
  if _idr is None:
    _idr = IDRCore()
  return _idr

