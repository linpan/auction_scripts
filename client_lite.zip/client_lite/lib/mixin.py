# encoding: UTF-8

import types

def MixIn(pyClass, mixInClass, makeAncestor=1):
   if makeAncestor:
     if mixInClass not in pyClass.__bases__:
        pyClass.__bases__ = (mixInClass,) + pyClass.__bases__
   else:
     # Recursively traverse the mix-in ancestor
     # classes in order to support inheritance
     baseClasses = list(mixInClass.__bases__)
     baseClasses.reverse()
     for baseClass in baseClasses:
        MixIn(pyClass, baseClass, 0)
     # Install the mix-in methods into the class
     for name in dir(mixInClass):
        if not name.startswith('__'):
        # skip private members
           member = getattr(mixInClass, name)
           if type(member) is types.MethodType:
               member = member.im_func
           setattr(pyClass, name, member)

def UnmixIn(pyClass, mixInClass):
  if mixInClass in pyClass.__bases__:
    pyClass.__bases__ = tuple([cls for cls in pyClass.__bases__ if cls != mixInClass])

