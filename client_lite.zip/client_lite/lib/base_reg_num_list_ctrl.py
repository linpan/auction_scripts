# encoding: UTF-8

from lib.utils import GetActiveActID
from lib.rest_client import *

class BaseRegNumListCtrlMixin:
  def act_id(self):
    if not self._act_id:
      self._act_id = GetActiveActID()
    return self._act_id

  def LoadRegNumData(self):
    js = get('/activity/%d/reg_nums' % self.act_id())
    return js['results'] and [dict(zip(js['keys'], d)) for d in js['results']]
