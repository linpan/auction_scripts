# encoding: UTF-8

import wx

from draw_helper import DrawHelper

FONTSIZE = 10

class PrintDrawHelper(DrawHelper):
  def DrawLogo(self, dc):
    x0, y0 = self.GetBasePos()
    dc.DrawBitmap(self.logo, x0, y0, True)

class GeneralPrintout(wx.Printout):
  def __init__(self, title, margins, page_datas):
    wx.Printout.__init__(self, title)

    self.page_datas = page_datas
    self.margins = margins
    self.numPages = len(page_datas)

  def HasPage(self, page):
    return page <= self.numPages

  def GetPageInfo(self):
    return (1, self.numPages, 1, self.numPages)

  def CalculateScale(self, dc):
    ppiPrinterX, ppiPrinterY = self.GetPPIPrinter()
    ppiScreenX, ppiScreenY = self.GetPPIScreen()
    logScale = float(ppiPrinterX)/float(ppiScreenX)

    pw, ph = self.GetPageSizePixels()
    dw, dh = dc.GetSize()
    scale = logScale * float(dw)/float(pw)
    dc.SetUserScale(scale, scale)
    # how many pixels per millimeter
    self.logUnitsMM = float(ppiPrinterX)/(logScale*25.4)

  def CalculateLayout(self, dc):
    topLeft, bottomRight = self.margins
    dw, dh = dc.GetSize()
    self.x1 = topLeft.x * self.logUnitsMM
    self.y1 = topLeft.y * self.logUnitsMM
    self.x2 = (dc.DeviceToLogicalXRel(dw) - bottomRight.x * self.logUnitsMM)
    self.y2 = (dc.DeviceToLogicalYRel(dh) - bottomRight.y * self.logUnitsMM)
    self.pageHeight = self.y2 - self.y1 - 2*self.logUnitsMM
    self.pageWidth = self.x2 - self.x1

  def OnPreparePrinting(self):
    dc = self.GetDC()
    self.CalculateScale(dc)
    self.CalculateLayout(dc)

  def OnPrintPage(self, page):
    ##NOTE: first entry is the default style
    self.default_style = self.page_datas[page-1][0]
    self.data = self.page_datas[page-1][1:]

    dc = self.GetDC()
    self.CalculateScale(dc)
    self.CalculateLayout(dc)
    dc.SetPen(wx.Pen("black", 0))
    dc.SetBrush(wx.TRANSPARENT_BRUSH)

    #r = wx.RectPP((self.x1, self.y1), (self.x2, self.y2))
    #dc.DrawRectangleRect(r)
    #dc.SetClippingRect(r)

    return self.DoPrint(dc, page)

  def GetBasePos(self):
    return self.x1 + self.logUnitsMM, self.y1 + self.logUnitsMM
