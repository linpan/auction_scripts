# encoding: UTF-8

import re
import types
import wx

class DrawHelper:
  def DrawDottedLine(self, dc, x, y, length, horizontal=True):
    dc.SetPen(wx.Pen("black"))
    dotted_line_len = 2
    space_len = 2

    x1 = x2 = x
    y1 = y2 = y
    while length > 0:
      if horizontal:
        x2 += min(dotted_line_len, length)
      else:
        y2 += min(dotted_line_len, length)
      dc.DrawLine(x1, y1, x2, y2)
      if horizontal:
        x1 = x2 + space_len
        x2 = x1
      else:
        y1 = y2 + space_len
        y2 = y1
      length -= (dotted_line_len + space_len)

  def ApplyFont(self, dc, fstyle):
    size = fstyle.get('size', 9)
    family = wx.DEFAULT
    style = fstyle.get('style', wx.NORMAL)
    weight = fstyle.get('weight', wx.NORMAL)
    underline = fstyle.get('underline', False)
    name = fstyle.get('name', u'Times')
    font = wx.Font(size, family, style, weight, underline, name)
    dc.SetFont(font)

  def ResetFont(self, dc):
    self.ApplyFont(dc, self.default_style['style']['font'])

  def HandleTextStyle(self, dc, elem, text):
    style = elem.get('style', {})
    font = style.get('font', None)
    if font:
      self.ApplyFont(dc, font)
    else:
      self.ResetFont(dc)

    color = style.get('color', None)
    if color:
      dc.SetTextForeground(color)
    else:
      dc.SetTextForeground(wx.BLACK)

    align = style.get('align', 'left')
    size = dc.GetTextExtent(text)
    pos = elem.get('position', {})
    width = self.GetAbsPos(pos.get('width', None), self.pageWidth)
    wrap = style.get('wrap', False)
    text_width = size[0]
    fitted_text = text
    remainder = ''
    if wrap and width and width < text_width:
      exts = dc.GetPartialTextExtents(text)
      for i, ext in enumerate(exts):
        #if ext > width:
        if ext > width and len(exts) != i+1:
          text_width = exts[i-1]
          fitted_text = text[0:i]
          remainder = text[i:]
          break
    next_y_offset = 0
    count = text.count('\n')
    if count:
      next_y_offset = size[1] * count

    if align == 'right':
      # for align right, 'x' and 'width' must be specified
      return width-text_width, 0, fitted_text, remainder, next_y_offset
    elif align == 'center':
      # for align right, 'x' and 'width' must be specified
      return (width-text_width)/2, 0, fitted_text, remainder, next_y_offset
    else:
      return -10,0, fitted_text, remainder, next_y_offset

  def GetAbsPos(self, val, total):
    if val is None: return
    if type(val) == types.StringType and val.endswith('%'):
      return total*float(val.rstrip('%'))/100.0
    else:
      new_val = float(val)
      if new_val < 0:
        new_val = total + new_val
      return new_val

  def DrawFormatData(self, dc):
    for elem in self.data:
      elem_type = elem.get('type', 'text')
      handler = getattr(self, 'Draw%sElement' % elem_type.capitalize())
      if not handler:
        raise Exception("no %s handle available" % elem_type)

      handler(dc, elem)

  #def DrawFancyElement(self, dc, elem, line_yoffset=0):
    #x0, y0 = self.GetBasePos()
    #pos = elem['position']

    #style = elem.get('style', {})
    #space = style.get('space', 0)

    #texts = elem['text']
    #if type(texts) != types.TupleType:
      #texts = (texts,)

    #total_yoffset = 0

    #for text in texts:
      #x = self.GetAbsPos(pos['x'], self.pageWidth)
      #y = self.GetAbsPos(pos['y'], self.pageHeight)
      #x += x0
      #y += total_yoffset + y0
      #fancytext.RenderToDC(text, dc, x, y)
      #total_yoffset += fancytext.GetTextExtent(text)[1] + space

  def DrawTextElement(self, dc, elem, line_yoffset=0, dry_run=False):
    x0, y0 = self.GetBasePos()
    pos = elem['position']

    style = elem.get('style', {})
    space = style.get('space', 0)

    texts = elem['text']
    if type(texts) != types.TupleType:
      texts = (texts,)
    total_yoffset = 0

    next_y_offset = 0
    for text in texts:
      remainder = text
      while remainder:
        x = self.GetAbsPos(pos['x'], self.pageWidth)
        y = self.GetAbsPos(pos['y'], self.pageHeight)
        xoffset, yoffset, fitted_text, remainder, n_y_o = \
            self.HandleTextStyle(dc, elem, remainder)

        x += xoffset + x0
        y += yoffset + total_yoffset + y0 + next_y_offset

        if not dry_run:
          dc.DrawText(fitted_text, x, y+line_yoffset)

        total_yoffset += dc.GetTextExtent(fitted_text)[1]
        next_y_offset = n_y_o
      total_yoffset += space

    return total_yoffset

  def DrawZebraLines(self, dc, pos_list, max_line_height, line_offset, space):
    x0, y0 = self.GetBasePos()

    # calculate row rect size
    tl_x0 = self.GetAbsPos(pos_list[0]['x'], self.pageWidth)
    tl_y0 = self.GetAbsPos(pos_list[0]['y'], self.pageHeight)
    br_x0 = self.GetAbsPos(pos_list[-1]['x'], self.pageWidth) + \
        self.GetAbsPos(pos_list[-1]['width'], self.pageWidth)
    padding = 4
    tl_y = y0+ tl_y0 + line_offset - space/2
    br_y = tl_y + max_line_height
    tl_x = max(0, tl_x0 + x0 - padding/2)
    br_x = br_x0 + x0
    width = br_x - tl_x + padding
    height = br_y-tl_y + space

    dc.SetBrush(wx.Brush("#F5F5F5", wx.SOLID))
    dc.SetPen(wx.TRANSPARENT_PEN)
    dc.DrawRectangle(tl_x, tl_y, width, height)
    dc.SetBrush(wx.TRANSPARENT_BRUSH)

  def DrawTableElement(self, dc, elem):
    style = elem['style']
    zebra = style.get('zebra', None)
    space = self.GetAbsPos(style.get('space', 0), self.pageHeight)
    tbl_data = elem['table']
    pos_list = tbl_data['positions']
    style_list = tbl_data['styles']
    rows = tbl_data['rows']
    line_offset = 0
    counter = 0

    for row in rows:
      if len(row) != len(style_list) or len(row) != len(pos_list):
        raise Exception('number of style or position not equals to num of rows!')

      # collect text rect info under dry_run mode
      max_line_height = 0
      for i,col in enumerate(row):
        col_info = {}
        col_info.update(col)
        if col_info.has_key('style'):
          col_info['style'].update(style_list[i])
        else:
          col_info['style'] = style_list[i]

        col_info['position'] = pos_list[i]
        line_height = self.DrawTextElement(dc, col_info, line_offset, True)
        max_line_height = max(max_line_height, line_height)

      if zebra and counter%2 == 1:
        self.DrawZebraLines(dc, pos_list, max_line_height, line_offset, space)

      max_line_height = 0
      for i,col in enumerate(row):
        col_info = {}
        col_info.update(col)
        if col_info.has_key('style'):
          col_info['style'].update(style_list[i])
        else:
          col_info['style'] = style_list[i]
        col_info['position'] = pos_list[i]
        line_height = self.DrawTextElement(dc, col_info, line_offset)
        max_line_height = max(max_line_height, line_height)

      line_offset += max_line_height + space
      counter += 1

  def DrawImageElement(self, dc, elem):
    x0, y0 = self.GetBasePos()
    pos = elem['position']
    image = elem['image']
    if type(image) in (types.StringType, types.UnicodeType):
      image = wx.Bitmap(image, wx.BITMAP_TYPE_JPEG)
    style = elem.get('style', {})
    align = style.get('align', 'left')
    valign = style.get('valign', 'top')

    x = self.GetAbsPos(pos['x'], self.pageWidth)
    y = self.GetAbsPos(pos['y'], self.pageHeight)

    if align == 'right':
      width = self.GetAbsPos(pos['width'], self.pageWidth)
      x += width-image.GetWidth()
    elif align == 'center':
      width = self.GetAbsPos(pos['width'], self.pageWidth)
      x += (width-image.GetWidth())/2
    else:
      pass

    if valign == 'bottom':
      height = self.GetAbsPos(pos['height'], self.pageHeight)
      y += height-image.GetHeight()
    elif valign == 'center':
      height = self.GetAbsPos(pos['height'], self.pageHeight)
      y += (height-image.GetHeight())/2
    else:
      pass

    x += x0
    y += y0
    dc.DrawBitmap(image, x, y)

  def DrawRegionElement(self, dc, elem):
    x0, y0 = self.GetBasePos()
    pos = elem['position']
    style = elem.get('style', {})
    color = style.get('color', 'black')

    x = x0 + self.GetAbsPos(pos['x'], self.pageWidth)
    y = y0 + self.GetAbsPos(pos['y'], self.pageHeight)
    width = self.GetAbsPos(pos['width'], self.pageWidth)
    height = self.GetAbsPos(pos['height'], self.pageHeight)

    dc.SetBrush(wx.Brush(color, wx.SOLID))
    dc.DrawRectangle(x, y, width, height)
    dc.SetBrush(wx.NullBrush)

  def DrawMarklineElement(self, dc, elem):
    #x0, y0 = self.GetBasePos()
    pos = elem['position']
    x = self.GetAbsPos(pos['x'], self.pageWidth)
    # y coordinate is not precise
    y = self.GetAbsPos(pos['y'], self.pageHeight) + self.logUnitsMM
    if pos.has_key('width'):
      width = self.GetAbsPos(pos['width'], self.pageWidth)
      dc.DrawLine(x, y, x+width, y)
    elif pos.has_key('height'):
      height = self.GetAbsPos(pos['height'], self.pageWidth)
      dc.DrawLine(x, y, x, y+height)
    else:
      raise Exception("no width or height provided!")


