# encoding: UTF-8

import time
import datetime
import types

import config

import wx

from rest_client import *

_activity = None

def GetActiveActName():
  act = GetActiveAct()
  if act:
    return act['name']
  else:
    return None

def GetActiveAct():
  global _activity
  if not _activity:
    _activity = get('/activity/active')
  return _activity

def GetActiveActID():
  act = GetActiveAct()
  if act:
    return act['id']
  else:
    return None

def GetAppWinTitle(app_title, sub_act_name=None):
  if sub_act_name:
    return u"%s(%s) - %s" % (GetActiveActName(), sub_act_name, app_title)
  else:
    return u"%s - %s" % (GetActiveActName(), app_title)

def PyDate2WxDate(date):
  if isinstance(date, wx.DateTime): return date
  assert isinstance(date, (datetime.datetime, datetime.date))
  tt = date.timetuple()
  dmy = (tt[2], tt[1]-1, tt[0])
  return wx.DateTimeFromDMY(*dmy)

def WxDate2PyDate(date):
  if isinstance(date, (datetime.datetime, datetime.date)): return date
  assert isinstance(date, wx.DateTime)
  if date.IsValid():
     ymd = map(int, date.FormatISODate().split('-'))
     return datetime.date(*ymd)
  else:
     return None

def del_none_values(d):
  return dict((k, d[k]) for k in d.keys() if d[k] is not None)

def inv_dict(d):
  return dict(zip(d.values(), d.keys()))

def money_amount_to_s(amount, use_float=False):
  if amount is '': return ''
  if amount is None: return '0'
  if not isinstance(amount, types.FloatType):
    try:
      amount = float(amount)
    except:
      raise Exception("invalid money amount data type(%s)" % type(amount))

  if use_float:
    return '{:,.2f}'.format(amount)
  else:
    amount = int(round(amount))
    return '{:,}'.format(amount)

def str_to_money_amount(str_amount):
  str_amount = str_amount.strip()
  if str_amount:
    return float(str_amount.replace(',', ''))
  else:
    return 0

def num_to_ch_char(num):
  mapping = [u'〇', u'一', u'二', u'三', u'四', u'五', u'六', u'七', u'八',
             u'九']
  return ''.join([mapping[int(c)] for c in str(num)])

def month_day_num_to_ch_char(num):
  mapping = [u'', u'一', u'二', u'三', u'四', u'五', u'六', u'七', u'八', u'九', u'十']
  vals = []
  vals.append(mapping[num%10])
  num = num / 10

  if num:
    vals.append(mapping[-1])

  if num > 1:
    vals.append(mapping[num])

  return ''.join(reversed(vals))

def gen_person_photo_dir(act_id, person_id=None):
  person_id = person_id or 'tmp_%s' % int(time.time())
  dir_path = os.path.join(config.card_photo_dir, str(act_id), str(person_id))
  if not os.path.exists(dir_path):
    os.makedirs(dir_path)
  return dir_path

