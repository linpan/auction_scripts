# encoding: UTF-8

from wx.lib.mixins.listctrl import CheckListCtrlMixin

class GeneralCheckListCtrlMixin(CheckListCtrlMixin):
  def _UncheckAll(self):
    for i in range(self.GetItemCount()):
      if self.IsChecked(i):
        self.CheckItem(i, False)

  def CheckAll(self):
    self.ResetFilters()
    for i in range(self.GetItemCount()):
      if not self.IsChecked(i):
        self.CheckItem(i, True)

  def CancelChecked(self):
    self.ResetFilters()
    self._UncheckAll()

  def CheckInversed(self):
    self.ResetFilters()
    for i in range(self.GetItemCount()):
      self.ToggleItem(i)

  def GetCheckedCount(self):
    count = 0
    for i in range(self.GetItemCount()):
      if self.IsChecked(i): count += 1
    return count

  def GetCheckedItems(self):
    items = []
    for i in range(self.GetItemCount()):
      if self.IsChecked(i): items.append(i)
    return items

  def CheckItemByData(self, filters, start=-1, select_all=True):
    self._UncheckAll()
    items = self.FilterItemByData(filters, start, select_all)
    for item in items: self.CheckItem(item, True)
