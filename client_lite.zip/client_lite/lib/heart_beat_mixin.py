# encoding: UTF-8

import os
import wx

import config

from lib.rest_client import *

class HeartBeatMixin:
  def OtherRunningClient(self):
    r = get('/heartbeat/%s' % self.AppName())
    return r['results']

  def StartHeartBeat(self):
    running_clients = self.OtherRunningClient()
    if running_clients:
      msg = u'其他客户端(%s)已经在运行, 确定要继续么? ' \
          % ','.join(running_clients)
      result = wx.MessageBox(msg,
                             u'提示信息',
                             wx.YES|wx.NO)
      if result == wx.NO:
        self.Destroy()
        return

    self.identifier = os.getpid()
    self.timer_id = 100
    self.timer = wx.Timer(self, self.timer_id)
    self.timer.Start(config.heart_beat_interval * 1000)
    wx.EVT_TIMER(self, self.timer_id, self.OnTimer)
    wx.EVT_CLOSE(self, self.OnClose)
    self.SendLiveMsg()

  def StopHeartBeat(self):
    self.timer.Stop()
    try:
      delete('/heartbeat/%s?identifier=%s' % (self.AppName(), self.identifier))
    except Exception:
      wx.GetApp().logger.error('failed to delete heartbeat info',
                               exc_info=True)

  def OnTimer(self, evt):
    self.SendLiveMsg()

  def OnClose(self, evt):
    self.StopHeartBeat()
    self.Destroy()

  def SendLiveMsg(self):
    post('/heartbeat/%s' % self.AppName(), {'identifier': self.identifier})

  def AppName(self):
    return wx.GetApp().__class__.__name__
