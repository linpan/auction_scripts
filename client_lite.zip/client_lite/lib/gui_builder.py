# encoding: UTF-8

import wx
from lib.validator import *

class GuiBuilderMixin:
  def BuildLabeledCtrl(self, label, label_size=wx.DefaultSize, sizer=None,
                       ctrl_type='TextCtrl', handler=None, _id=wx.ID_ANY,
                       ratio=1, post_label=None, params=None):
    params = params and params or {}
    sizer = sizer and sizer or wx.BoxSizer(wx.HORIZONTAL)

    if label:
      label_ctrl = wx.StaticText(self, wx.ID_ANY, label, size=label_size)
      sizer.Add(label_ctrl, 0, wx.ALIGN_CENTER_VERTICAL)

    ctrl_cls = eval("wx.%s" % ctrl_type)
    ctrl = ctrl_cls(self, _id, **params)
    if handler: handler(ctrl)
    sizer.Add(ctrl, ratio, wx.LEFT|wx.ALIGN_CENTER_VERTICAL, 2)

    if post_label:
      label_ctrl = wx.StaticText(self, label=post_label)
      sizer.Add(label_ctrl, 0, wx.ALIGN_CENTER_VERTICAL|wx.LEFT, 3)
    return sizer

  def BuildCtrlsByConfig(self, sizer, cfgs, expanded=True):
    old_sizer = None
    for cfg in cfgs:
      use_old_sizer = cfg.pop('use_old_sizer', False)
      if use_old_sizer:
        cfg['sizer'] = old_sizer
        old_sizer.AddSpacer(cfg.pop('spacer', (10,10)))
      outer_ratio = cfg.pop('outer_ratio', 1)
      spacer = cfg.pop('spacer', (10,10))
      old_sizer = self.BuildLabeledCtrl(**cfg)
      if not use_old_sizer:
        if expanded:
          sizer.Add(old_sizer, outer_ratio, wx.EXPAND)
        else:
          sizer.Add(old_sizer, outer_ratio)
        sizer.Add(spacer)

class GetNumberDialog(wx.Dialog):
  def __init__(self, parent, title, label, default_value=0):
    wx.Dialog.__init__(self, parent, title=title)

    self.value = -1
    self.values = {'value': default_value}

    sizer = wx.BoxSizer(wx.VERTICAL)
    hsizer = wx.BoxSizer(wx.HORIZONTAL)
    hsizer.Add(wx.StaticText(self, label=label), 0,
               wx.ALIGN_CENTER_VERTICAL|wx.RIGHT, 10)
    v_cls = GetValidator(NumberValidatorMixin)
    txt = wx.TextCtrl(self, wx.ALIGN_CENTER_VERTICAL,
                      validator=v_cls(self.values, 'value'))
    hsizer.Add(txt, 1, wx.ALIGN_CENTER_VERTICAL, 5)
    sizer.Add(hsizer, 0, wx.ALIGN_CENTER_VERTICAL|wx.EXPAND|wx.ALL, 15)

    sizer.Add(self.CreateButtonSizer(wx.OK|wx.CANCEL), 0,
              wx.ALIGN_RIGHT|wx.ALL, 15)
    self.Bind(wx.EVT_BUTTON, self.OnOK, id=wx.ID_OK)
    self.Bind(wx.EVT_BUTTON, self.OnClose, id=wx.ID_CLOSE)

    self.SetSizerAndFit(sizer)

  def OnOK(self, evt):
    if self.Validate() and self.TransferDataFromWindow():
      self.value = float(self.values['value'])
      evt.Skip()
    else:
      wx.MessageBox(u'输入信息错误!', u'错误信息')

  def OnClose(self, evt):
    self.Close()

  def GetValue(self):
    return self.value

