# encoding: UTF-8

import wx

class BaseListCtrlMixin:
  def GetSelectedItem(self, start_index=-1):
    result = self.GetNextItem(start_index, wx.LIST_NEXT_ALL, wx.LIST_STATE_SELECTED)
    if result == -1:
      return None
    else:
      return result

  def GetColumnText(self, index, col):
    item = self.GetItem(index, col)
    return item.GetText()

  def FindColumnByText(self, text):
    for i in range(self.GetColumnCount()):
      item = self.GetColumn(i)
      if item.m_text == text: return i

  def SelectItem(self, index):
    self.SetItemState(index, wx.LIST_STATE_SELECTED, wx.LIST_STATE_SELECTED)

  def UnselectItem(self, index):
    self.SetItemState(index, 0, wx.LIST_STATE_SELECTED)

  def IsItemSelected(self, index):
    return self.GetItemState(index, wx.LIST_STATE_SELECTED) != 0

  def FocusItem(self, idx):
    self.SetItemState(idx, wx.LIST_STATE_FOCUSED, wx.LIST_STATE_FOCUSED)
    self.EnsureVisible(idx)

  def GetFocusedItem(self):
    '''get the currently focused item or -1 if none'''
    return self.GetNextItem(-1, wx.LIST_NEXT_ALL, wx.LIST_STATE_FOCUSED)

  #def Append(self, entry):
      #”’Append an item to the list control.  The entry parameter
  #should be a sequence with an item for each column”’
      #if len(entry):
          #if wx.USE_UNICODE:
              #cvtfunc = unicode
          #else:
              #cvtfunc = str
          #pos = self.GetItemCount()
          #self.InsertStringItem(pos, cvtfunc(entry[0]))
          #for i in range(1, len(entry)):
              #self.SetStringItem(pos, i, cvtfunc(entry[i]))
          #return pos

