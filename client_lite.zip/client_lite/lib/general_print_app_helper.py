# encoding: UTF-8

import wx

class GeneralPrintAppHelper:
  def DoInit(self, orientation=wx.PORTRAIT, num_copies=1,
             paper_id=wx.PAPER_A4, margins=None):
    self.pdata = wx.PrintData()
    self.pdata.SetPaperId(paper_id)
    self.pdata.SetOrientation(orientation)
    self.pdata.SetNoCopies(num_copies)
    self.printer = None
    self.margins = margins or (wx.Point(10,10), wx.Point(10,10))

  def DoPreview(self, title, format_data, printout_cls):
    data = wx.PrintDialogData(self.pdata)
    po1 = printout_cls(u"%s" % title, self.margins, format_data)
    po2 = printout_cls(u"%s" % title, self.margins, format_data)

    preview = wx.PrintPreview(po1, po2, data)
    preview.SetZoom(100)
    if not preview.Ok():
      wx.MessageBox(u"创建打印预览失败!", u"错误信息")
    else:
      frame = wx.PreviewFrame(preview, wx.GetApp().TopWindow,
                              u"打印预览 - %s" % title,
                             size=(1000, 800))
      frame.Initialize()
      frame.Center()
      frame.Show()

  def DoPrint(self, title, format_data, printout_cls, show_setup=True):
    if not self.printer:
      data = wx.PrintDialogData(self.pdata)
      self.printer = wx.Printer(data)

    po = printout_cls(u"%s" % title, self.margins, format_data)
    if not self.printer.Print(self, po, show_setup) \
       and self.printer.GetLastError() == wx.PRINTER_ERROR:
      wx.MessageBox(u'打印失败, 请确认打印机已经设置正确', u'打印错误信息', wx.OK)
    else:
      data = self.printer.GetPrintDialogData()
      self.pdata = wx.PrintData(data.GetPrintData()) # force a copy
    po.Destroy()

  def GetPageDatas(self, all_items, num_units=1):
    page_datas = []
    total_page_num = int(len(all_items) / self.rows_per_page)
    if total_page_num*self.rows_per_page < len(all_items):
      total_page_num += 1
    for unit_no in range(num_units):
      start_index = 0
      end_index = 0
      page_num = 0
      while True:
        start_index = end_index
        end_index = start_index + self.rows_per_page
        page_num += 1
        items = all_items[start_index:end_index]
        if not items:
          break
        data = self.GetPrintFormatData(items, unit_no, page_num, total_page_num)
        page_datas.append(data)
    return page_datas

  def GetPageDatasEx(self, all_items, num_units=1):
    page_datas = []
    for unit_no in range(num_units):
      new_all_items = list(reversed(all_items))
      unit_page_datas = []
      page_num = 0
      while True:
        if not new_all_items:
          total_page_num = page_num
          for index, page_data in enumerate(unit_page_datas):
            cur_page_num = index + 1
            page_data += self.GetPaginationFormatData(cur_page_num, total_page_num)
          break
        page_num += 1
        data = self.GetPrintFormatDataEx(new_all_items, unit_no, page_num)
        unit_page_datas.append(data)
      page_datas += unit_page_datas
    return page_datas
