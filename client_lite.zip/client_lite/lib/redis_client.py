# encoding: UTF-8

import config
import redis

_redis = None
def get_redis():
  global _redis
  if _redis is None:
    _redis = redis.StrictRedis(config.redis_host,
                               config.redis_port, db=0)
  return _redis

